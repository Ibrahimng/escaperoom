<div class="wrap">
	<h2><?php _e( 'Global Availability', 'woocommerce-bookings' ); ?></h2>

	<div id="content">

		<?php
			include( 'html-global-availability-settings.php' );
		?>

	</div>

</div>
