<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class for the booking product type
 */
class WC_Product_Booking extends WC_Product {
	private $availability_rules = array();

	/**
	 * Constructor
	 */
	public function __construct( $product ) {
		if ( empty( $this->product_type ) ) {
			$this->product_type = 'booking';
		}

		parent::__construct( $product );
	}

	/**
	 * If this product class is a skelton/place holder class (used for booking addons)
	 * @return boolean
	 */
	public function is_skeleton() {
		return false;
	}

	/**
	 * If this product class is an addon for bookings
	 * @return boolean
	 */
	public function is_bookings_addon() {
		return false;
	}

	/**
	 * Extension/plugin/add-on name for the booking addon this product refers to
	 * @return string
	 */
	public function bookings_addon_title() {
		return '';
	}

	/**
	 * We want to sell bookings one at a time
	 * @return boolean
	 */
	public function is_sold_individually() {
		return true;
	}

	/**
	 * Bookings can always be purchased regardless of price.
	 * @return boolean
	 */
	public function is_purchasable() {

		$purchasable = true;

		// Products must exist of course
		if ( ! $this->exists() ) {
			$purchasable = false;
		} elseif ( 'publish' !== $this->post->post_status && ! current_user_can( 'edit_post', $this->id ) ) {
			$purchasable = false;
		}

		return apply_filters( 'woocommerce_is_purchasable', $purchasable, $this );
	}

	/**
	 * Get tje qty available to book per block.
	 * @return boolean
	 */
	public function get_qty() {
		return $this->wc_booking_qty ? absint( $this->wc_booking_qty ) : 1;
	}

	/**
	 * See if this booking product has persons enabled.
	 * @return boolean
	 */
	public function has_persons() {
		return 'yes' === $this->wc_booking_has_persons;
	}

	/**
	 * See if this booking product has person types enabled.
	 * @return boolean
	 */
	public function has_person_types() {
		return 'yes' === $this->wc_booking_has_person_types;
	}

	/**
	 * See if persons affect the booked qty
	 * @return boolean
	 */
	public function has_person_qty_multiplier() {
		return $this->has_persons() && 'yes' === $this->wc_booking_person_qty_multiplier;
	}

	/**
	 * Get persons allowed per group
	 * @return int
	 */
	public function get_min_persons() {
		return absint( $this->wc_booking_min_persons_group );
	}

	/**
	 * Get persons allowed per group
	 * @return int
	 */
	public function get_max_persons() {
		return absint( $this->wc_booking_max_persons_group );
	}

	/**
	 * See if this booking product has reasources enabled.
	 * @return boolean
	 */
	public function has_resources() {
		return 'yes' === $this->wc_booking_has_resources;
	}

	/**
	 * get duration
	 * @return string
	 */
	public function get_duration() {
		return $this->wc_booking_duration;
	}

	/**
	 * get duration
	 * @return string
	 */
	public function get_duration_unit() {
		return apply_filters( 'woocommerce_bookings_get_duration_unit', $this->wc_booking_duration_unit, $this );
	}

	/**
	 * Get duration type
	 * @return string
	 */
	public function get_duration_type() {
		return $this->wc_booking_duration_type;
	}

	/**
	 * Test duration type
	 * @return string
	 */
	public function is_duration_type( $type ) {
		return $this->wc_booking_duration_type === $type;
	}

	/**
	 * Get duration setting
	 * @return int
	 */
	public function get_min_duration() {
		return absint( $this->wc_booking_min_duration );
	}

	/**
	 * Get duration setting
	 * @return int
	 */
	public function get_max_duration() {
		return absint( $this->wc_booking_max_duration );
	}

	/**
	 * is_range_picker_enabled
	 * @return bool
	 */
	public function is_range_picker_enabled() {
		return 'yes' === $this->wc_booking_enable_range_picker && 'day' === $this->get_duration_unit() && $this->is_duration_type( 'customer' ) && 1 == $this->get_duration();
	}

	/**
	 * The base cost will either be the 'base' cost or the base cost + cheapest resource
	 * @return string
	 */
	public function get_base_cost() {
		if ( '' !== $this->wc_display_cost ) {
			return $this->wc_display_cost;
		}

		$base = ( $this->wc_booking_base_cost * $this->get_min_duration() ) + $this->wc_booking_cost;

		if ( $this->has_resources() ) {
			$resources = $this->get_resources();
			$cheapest  = null;

			foreach ( $resources as $resource ) {
				if ( is_null( $cheapest ) || ( $resource->get_base_cost() + $resource->get_block_cost() ) < $cheapest ) {
					$cheapest = $resource->get_base_cost() + $resource->get_block_cost();
				}
			}
			$base += $cheapest;
		}
		if ( $this->has_persons() && $this->has_person_types() ) {
			$persons   = $this->get_person_types();
			$cheapest  = null;
			foreach ( $persons as $person ) {
				$cost = $person->cost * $person->min;
				if ( is_null( $cheapest ) || $cost < $cheapest ) {
					if ( $cost ) {
						$cheapest = $cost;
					}
				}
			}
			$base += $cheapest ? $cheapest : 0;
		}
		if ( $this->has_persons() && $this->get_min_persons() > 1 && 'yes' === $this->wc_booking_person_cost_multiplier ) {
			$base = $base * $this->get_min_persons();
		}

		return $base;
	}

	/**
	 * Return if booking has extra costs
	 * @return bool
	 */
	public function has_additional_costs() {
		$has_additional_costs = 'yes' === $this->has_additional_costs;

		if ( $this->has_persons() && 'yes' === $this->wc_booking_person_cost_multiplier ) {
			$has_additional_costs = true;
		}

		if ( $this->get_min_duration() > 1 && $this->wc_booking_base_cost ) {
			$has_additional_costs = true;
		}

		return $has_additional_costs;
	}

	/**
	 * Get product price
	 * @return string
	 */
	public function get_price() {
		return apply_filters( 'woocommerce_get_price', $this->price ? $this->price : $this->get_base_cost(), $this );
	}

	/**
	 * Get price HTML
	 * @param string $price
	 * @return string
	 */
	public function get_price_html( $price = '' ) {
		$tax_display_mode = get_option( 'woocommerce_tax_display_shop' );
		$display_price    = 'incl' == $tax_display_mode ? $this->get_price_including_tax( 1, $this->get_price() ) : $this->get_price_excluding_tax( 1, $this->get_price() );

		if ( $display_price ) {
			if ( $this->has_additional_costs() ) {
				$price_html = sprintf( __( 'From: %s', 'woocommerce-bookings' ), wc_price( $display_price ) ) . $this->get_price_suffix();
			} else {
				$price_html = wc_price( $display_price ) . $this->get_price_suffix();
			}
		} elseif ( ! $this->has_additional_costs() ) {
			$price_html = __( 'Free', 'woocommerce-bookings' );
		} else {
			$price_html = '';
		}
		return apply_filters( 'woocommerce_get_price_html', $price_html, $this );
	}

	/**
	 * Find the minimum block's timestamp based on settings
	 * @return int
	 */
	public function get_min_timestamp_for_date( $start_date ) {
		$current_timestamp = current_time( 'timestamp' );

		$timestamp = $start_date;
		$today     = date( 'y-m-d', $start_date ) === date( 'y-m-d', $current_timestamp );
		$min = $this->get_min_date();
		if ( $min  && $today || empty( $start_date ) ) {
			$timestamp = strtotime( "midnight +{$min['value']} {$min['unit']}", $current_timestamp );
		}

		return $timestamp;
	}

	/**
	 * Get Min date
	 * @return array|bool
	 */
	public function get_min_date() {
		$min_date['value'] = ! empty( $this->wc_booking_min_date ) ? apply_filters( 'woocommerce_bookings_min_date_value', absint( $this->wc_booking_min_date ), $this->id ) : 0;
		$min_date['unit']  = ! empty( $this->wc_booking_min_date_unit ) ? apply_filters( 'woocommerce_bookings_min_date_unit', $this->wc_booking_min_date_unit, $this->id ) : 'month';
		if ( $min_date['value'] ) {
			return $min_date;
		}
		return false;
	}

	/**
	 * Get max date
	 * @return array
	 */
	public function get_max_date() {
		$max_date['value'] = ! empty( $this->wc_booking_max_date ) ? apply_filters( 'woocommerce_bookings_max_date_value', absint( $this->wc_booking_max_date ), $this->id ) : 1;
		$max_date['unit']  = ! empty( $this->wc_booking_max_date_unit ) ? apply_filters( 'woocommerce_bookings_max_date_unit', $this->wc_booking_max_date_unit, $this->id ) : 'month';
		if ( $max_date['value'] ) {
			return $max_date;
		}
		return false;
	}

	/**
	 * Get max year
	 * @return string
	 */
	private function get_max_year() {
		// Find max to get first
		$max_date = $this->get_max_date();
		$max_date_timestamp = strtotime( "+{$max_date['value']} {$max_date['unit']}" );
		$max_year = date( 'Y', $max_date_timestamp );
		if ( ! $max_year ) {
			$max_year = date( 'Y' );
		}
		return $max_year;
	}

	/**
	 * Get person type by ID
	 * @param  int $id
	 * @return WP_POST object
	 */
	public function get_person( $id ) {
		$id = absint( $id );

		if ( $id ) {
			$person = get_post( $id );

			if ( 'bookable_person' == $person->post_type && $person->post_parent == $this->id ) {
				return $person;
			}
		}

		return false;
	}

	/**
	 * Get all person types
	 * @return array of WP_Post objects
	 */
	public function get_person_types() {
		return get_posts( array(
			'post_parent'    => $this->id,
			'post_type'      => 'bookable_person',
			'post_status'    => 'publish',
			'posts_per_page' => -1,
			'orderby'        => 'menu_order',
			'order'          => 'asc',
		) );
	}

	/**
	 * Get resource by ID
	 * @param  int $id
	 * @return WC_Product_Booking_Resource object
	 */
	public function get_resource( $id ) {
		global $wpdb;

		$id = absint( $id );

		if ( $id ) {
			$transient_name = 'book_res_' . md5( http_build_query( array( $id, $this->id, WC_Cache_Helper::get_transient_version( 'bookings' ) ) ) );

			if ( false === ( $relationship_id = get_transient( $transient_name ) ) ) {
				$relationship_id = $wpdb->get_var( $wpdb->prepare( "SELECT ID FROM {$wpdb->prefix}wc_booking_relationships WHERE product_id = %d AND resource_id = %d", $this->id, $id ) );
				set_transient( $transient_name, $relationship_id, DAY_IN_SECONDS * 30 );
			}

			$resource = get_post( $id );

			if ( 'bookable_resource' == is_object( $resource ) && $resource->post_type  && 0 < $relationship_id ) {
				return new WC_Product_Booking_Resource( $resource, $this->id );
			}
		}

		return false;
	}

	/**
	 * How resources are assigned
	 * @return string customer or automatic
	 */
	public function is_resource_assignment_type( $type ) {
		return $this->wc_booking_resources_assignment === $type;
	}

	/**
	 * Get all resources
	 * @return array of WP_Post objects
	 */
	public function get_resources() {
		$transient_name = 'book_ress_' . md5( http_build_query( array( $this->id, WC_Cache_Helper::get_transient_version( 'bookings' ) ) ) );

		if ( false === ( $product_resources = get_transient( $transient_name ) ) ) {
			$product_resources = wc_booking_get_product_resources( $this->id );
			set_transient( $transient_name, $product_resources, DAY_IN_SECONDS * 30 );
		}

		return $product_resources;
	}

	/**
	 * Get array of costs
	 *
	 * @return array
	 */
	public function get_costs() {
		return WC_Product_Booking_Rule_Manager::process_cost_rules( $this->wc_booking_pricing );
	}

	/**
	 * See if dates are by default bookable
	 * @return bool
	 */
	public function get_default_availability() {
		return 'available' === $this->wc_booking_default_date_availability;
	}

	/**
	 * Checks if a product requires confirmation.
	 *
	 * @return bool
	 */
	public function requires_confirmation() {
		return apply_filters( 'woocommerce_booking_requires_confirmation', 'yes' === $this->wc_booking_requires_confirmation, $this );
	}

	/**
	 * See if the booking can be cancelled.
	 *
	 * @return boolean
	 */
	public function can_be_cancelled() {
		return apply_filters( 'woocommerce_booking_user_can_canel', 'yes' === $this->wc_booking_user_can_cancel, $this );
	}

	/**
	 * Get the add to cart button text for the single page
	 *
	 * @return string
	 */
	public function single_add_to_cart_text() {
		return 'yes' === $this->wc_booking_requires_confirmation ? apply_filters( 'woocommerce_booking_single_check_availability_text', __( 'Check Availability', 'woocommerce-bookings' ), $this ) : apply_filters( 'woocommerce_booking_single_add_to_cart_text', __( 'Book now', 'woocommerce-bookings' ), $this );
	}

	/**
	 * Return an array of resources which can be booked for a defined start/end date
	 * @param  string $start_date
	 * @param  string $end_date
	 * @param  string $resource_id
	 * @param  integer $qty being booked
	 * @return bool|WP_ERROR if no blocks available, or int count of bookings that can be made, or array of available resources
	 */
	public function get_available_bookings( $start_date, $end_date, $resource_id = '', $qty = 1 ) {
		// Check the date is not in the past
		if ( date( 'Ymd', $start_date ) < date( 'Ymd', current_time( 'timestamp' ) ) ) {
			return false;
		}

		// Check we have a resource if needed
		$booking_resource = $resource_id ? $this->get_resource( $resource_id ) : null;

		if ( $this->has_resources() && ! is_numeric( $resource_id ) ) {
			return false;
		}

		$min_date   = $this->get_min_date();
		$max_date   = $this->get_max_date();
		$check_from = strtotime( "midnight +{$min_date['value']} {$min_date['unit']}", current_time( 'timestamp' ) );
		$check_to   = strtotime( "+{$max_date['value']} {$max_date['unit']}", current_time( 'timestamp' ) );

		// Min max checks
		if ( 'month' === $this->get_duration_unit() ) {
			$check_to = strtotime( 'midnight', strtotime( date( 'Y-m-t', $check_to ) ) );
		}
		if ( $end_date < $check_from || $start_date > $check_to ) {
			return false;
		}

		// Get availability of each resource - no resource has been chosen yet
		if ( $this->has_resources() && ! $resource_id ) {
			return $this->get_all_resources_availability( $start_date, $end_date, $qty );

		} else {
			// If we are checking for bookings for a specific resource, or have none.
			$check_date     = $start_date;

			while ( $check_date < $end_date ) {
				if ( ! $this->check_availability_rules_against_date( $check_date, $resource_id ) ) {
					return false;
				}
				if ( 'start' === $this->wc_booking_check_availability_against ) {
					break; // Only need to check first day
				}
				$check_date = strtotime( '+1 day', $check_date );
			}

			if ( in_array( $this->get_duration_unit(), array( 'minute', 'hour' ) ) && ! $this->check_availability_rules_against_time( $start_date, $end_date, $resource_id ) ) {
				return false;
			}

			// Get blocks availability
			return $this->get_blocks_availability( $start_date, $end_date, $qty, $resource_id, $booking_resource );
		}
	}

	/**
	 * Get the availability of all resources
	 *
	 * @param string $start_date
	 * @param string $end_date
	 * @return array| WP_Error
	 */
	public function get_all_resources_availability( $start_date, $end_date, $qty ) {
		$resources           = $this->get_resources();
		$available_resources = array();

		foreach ( $resources as $resource ) {
			$availability = $this->get_available_bookings( $start_date, $end_date, $resource->ID, $qty );

			if ( $availability && ! is_wp_error( $availability ) ) {
				$available_resources[ $resource->ID ] = $availability;
			}
		}

		if ( empty( $available_resources ) ) {
			return new WP_Error( 'Error', __( 'This block cannot be booked.', 'woocommerce-bookings' ) );
		}

		return $available_resources;
	}

	/**
	 * Check the resources availability against all the blocks.
	 *
	 * @param  string $start_date
	 * @param  string $end_date
	 * @param  int    $qty
	 * @param  int    $resource_id
	 * @param  object $booking_resource
	 * @return string|WP_Error
	 */
	public function get_blocks_availability( $start_date, $end_date, $qty, $resource_id, $booking_resource ) {
		$blocks   = $this->get_blocks_in_range( $start_date, $end_date, '', $resource_id );
		$interval = 'hour' === $this->get_duration_unit() ? $this->get_duration() * 60 : $this->get_duration();

		if ( ! $blocks ) {
			return false;
		}

		/**
		 * Grab all existing bookings for the date range
		 * @var array
		 */
		$existing_bookings = $this->get_bookings_in_date_range( $start_date, $end_date, $resource_id );
		$available_qtys    = array();

		// Check all blocks availability
		foreach ( $blocks as $block ) {
			$available_qty       = $this->has_resources() && $booking_resource->has_qty() ? $booking_resource->get_qty() : $this->get_qty();
			$qty_booked_in_block = 0;

			foreach ( $existing_bookings as $existing_booking ) {
				if ( $existing_booking->is_booked_on_day( $block, strtotime( "+{$interval} minutes", $block ) ) ) {
					$qty_to_add = $this->has_person_qty_multiplier() ? max( 1, array_sum( $existing_booking->get_persons() ) ) : 1;

					if ( $this->has_resources() ) {
						if ( $existing_booking->get_resource_id() === absint( $resource_id ) || ( ! $booking_resource->has_qty() && $existing_booking->get_resource() && ! $existing_booking->get_resource()->has_qty() ) ) {
							$qty_booked_in_block += $qty_to_add;
						}
					} else {
						$qty_booked_in_block += $qty_to_add;
					}
				}
			}

			if ( 'day' !== $this->get_duration_unit() ) {
				$available_qty = $available_qty - $qty_booked_in_block;
			}

			// Remaining places are less than requested qty, return an error.
			if ( $available_qty < $qty ) {
				if ( in_array( $this->get_duration_unit(), array( 'hour', 'minute' ) ) ) {
					return new WP_Error( 'Error', sprintf(
						_n( 'There is %d place remaining', 'There are %d places remaining', $available_qty , 'woocommerce-bookings' ),
						$available_qty
					) );
				} elseif ( ! $available_qtys ) {
					return new WP_Error( 'Error', sprintf(
						_n( 'There is %1$d place remaining on %2$s', 'There are %1$d places remaining on %2$s', $available_qty , 'woocommerce-bookings' ),
						$available_qty,
						date_i18n( wc_date_format(), $block )
					) );
				} else {
					return new WP_Error( 'Error', sprintf(
						_n( 'There is %1$d place remaining on %2$s', 'There are %1$d places remaining on %2$s', $available_qty , 'woocommerce-bookings' ),
						max( $available_qtys ),
						date_i18n( wc_date_format(), $block )
					) );
				}
			}

			$available_qtys[] = $available_qty;
		}

		return min( $available_qtys );
	}

	/**
	 * Get existing bookings in a given date range
	 *
	 * @param string $start_date
	 * @param string $end_date
	 * @param int    $resource_id
	 * @return array
	 */
	public function get_bookings_in_date_range( $start_date, $end_date, $resource_id = null ) {
		if ( $this->has_resources() && $resource_id ) {
			return WC_Bookings_Controller::get_bookings_in_date_range( $start_date, $end_date, $resource_id );
		} else {
			return WC_Bookings_Controller::get_bookings_in_date_range( $start_date, $end_date, $this->id );
		}
	}

	/**
	 * Get rules in order of `override power`. The higher the index the higher the override power. Element at index 4 will
	 * override element at index 2.
	 *
	 * Within priority the rules will be ordered top to bottom.
	 *
	 * @return array  availability_rules {
	 *    @type $resource_id => array {
	 *
	 *       The $order_index depicts the levels override. `0` Is the lowest. `1` overrides `0` and `2` overrides `1`.
	 *       e.g. If monday is set to available in `1` and not available in `2` the results should be that Monday is
	 *       NOT available because `2` overrides `1`.
	 *       $order_index corresponds to override power. The higher the element index the higher the override power.
	 *       @type $order_index => array {
	 *          @type string $type   The type of range selected in admin.
	 *          @type string $range  Depending on the type this depicts what range and if available or not.
	 *          @type integer $priority
	 *          @type string $level Global, Product or Resource
	 *          @type integer $order The index for the order set in admin.
	 *      }
	 * }
	 */
	public function get_availability_rules( $for_resource = 0 ) {
		if ( empty( $this->availability_rules[ $for_resource ] ) ) {
			$this->availability_rules[ $for_resource ] = array();

			// Rule types
			$resource_rules = array();
			$product_rules  = $this->wc_booking_availability;
			$global_rules   = get_option( 'wc_global_booking_availability', array() );

			// Get availability of each resource - no resource has been chosen yet
			if ( $this->has_resources() && ! $for_resource ) {
				$resources      = $this->get_resources();
				$resource_rules = array();

				if ( $this->get_default_availability() ) {
					// If all blocks are available by default, we should not hide days if we don't know which resource is going to be used.
				} else {
					foreach ( $resources as $resource ) {
						$resource_rule = (array) get_post_meta( $resource->ID, '_wc_booking_availability', true );
						$resource_rules = array_merge( $resource_rules, $resource_rule );
					}
				}
			} elseif ( $for_resource ) {
				// Standard handling
				$resource_rules = (array) get_post_meta( $for_resource, '_wc_booking_availability', true );
			}

			$availability_rules = array_filter( array_merge( WC_Product_Booking_Rule_Manager::process_availability_rules( $resource_rules, 'resource' ), WC_Product_Booking_Rule_Manager::process_availability_rules( $product_rules, 'product' ), WC_Product_Booking_Rule_Manager::process_availability_rules( $global_rules, 'global' ) ) );

			usort( $availability_rules, array( $this, 'rule_override_power_sort' ) );

			$this->availability_rules[ $for_resource ] = $availability_rules;
		}

		return apply_filters( 'woocommerce_booking_get_availability_rules', $this->availability_rules[ $for_resource ], $for_resource, $this );
	}

	/**
	 * Sort rules in order of precedence.
	 *
	 * @version 1.9.14 sort order reversed
	 * The order produced will be from the lowest to the highest.
	 * The elements with higher indexes overrides those with lower indexes e.g. `4` overrides `3`
	 * Index corresponds to override power. The higher the element index the higher the override power
	 *
	 * Level    : `global` > `product` > `product` (greater in terms off override power)
	 * Priority : within a level
	 * Order    : Within a priority The lower the order index higher the override power.
	 *
	 * @param array $rule1
	 * @param array $rule2
	 *
	 * @return integer
	 */
	public function rule_override_power_sort( $rule1, $rule2 ) {

		$level_weight = array(
			'resource' => 1,
			'product' => 3,
			'global' => 5,
		);

		if ( $level_weight[ $rule1['level'] ] === $level_weight[ $rule2['level'] ] ) {
			if ( $rule1['priority'] === $rule2['priority'] ) {
				// if `order index of 1` < `order index of 2` $rule1 one has a higher override power. So we
				// increase the index for $rule1 which corresponds to override power.
				return ( $rule1['order'] < $rule2['order'] ) ? 1 : -1;
			}

			// if `priority of 1` < `priority of 2` $rule1 must have lower override power. So we
			// decrease the index for 1 which corresponds to override power.
			return $rule1['priority'] < $rule2['priority'] ? 1 : -1;
		}

		// if `level of 1` < `level of 2` $rule1 must have lower override power. So we
		// decrease the index for 1 which corresponds to override power.
		return $level_weight[ $rule1['level'] ] < $level_weight[ $rule2['level'] ] ? -1 : 1;
	}

	/**
	 * Check a date against the availability rules
	 *
	 * @version 1.9.14 removed all calls to break 2 to ensure we get to the highest
	 *                 priority rules, otherwise higher order/priority rules will not
	 *                 override lower ones and the function exit with the wrong value.
	 *
	 * @param  string $check_date date to check
	 *
	 * @return bool available or not
	 */
	public function check_availability_rules_against_date( $check_date, $resource_id ) {
		$year        = date( 'Y', $check_date );
		$month       = absint( date( 'm', $check_date ) );
		$day         = absint( date( 'd', $check_date ) );
		$day_of_week = absint( date( 'N', $check_date ) );
		$week        = absint( date( 'W', $check_date ) );
		$bookable    = $default_availability = $this->get_default_availability();

		foreach ( $this->get_availability_rules( $resource_id ) as $rule ) {
			$type  = $rule['type'];
			$rules = $rule['range'];

			switch ( $type ) {
				case 'months' :
					if ( isset( $rules[ $month ] ) ) {
						$bookable = $rules[ $month ];
					}
					break;
				case 'weeks':
					if ( isset( $rules[ $week ] ) ) {
						$bookable = $rules[ $week ];
					}
					break;
				case 'days' :
					if ( isset( $rules[ $day_of_week ] ) ) {
						$bookable = $rules[ $day_of_week ];
					}
				break;
				case 'custom' :
					if ( isset( $rules[ $year ][ $month ][ $day ] ) ) {
						$bookable = $rules[ $year ][ $month ][ $day ];
					}
					break;
				case 'time':
				case 'time:1':
				case 'time:2':
				case 'time:3':
				case 'time:4':
				case 'time:5':
				case 'time:6':
				case 'time:7':
					if ( false === $default_availability && ( $day_of_week === $rules['day'] || 0 === $rules['day'] ) ) {
						$bookable = $rules['rule'];
					}
					break;
				case 'time:range':
					if ( false === $default_availability && ( isset( $rules[ $year ][ $month ][ $day ] ) ) ) {
						$bookable = $rules[ $year ][ $month ][ $day ]['rule'];
					}
					break;
			}
		}

		return $bookable;
	}

	/**
	 * Check a time against the time specific availability rules
	 *
*@param  string       $slot_start_time timestamp to check
	 * @param  string $slot_end_time   timestamp to check
	 *
*@return bool available or not
	 */
	public function check_availability_rules_against_time( $slot_start_time, $slot_end_time, $resource_id ) {
		$bookable        = $this->get_default_availability();
		$slot_start_time = is_numeric( $slot_start_time ) ? $slot_start_time : strtotime( $slot_start_time );
		$slot_end_time   = is_numeric( $slot_end_time ) ? $slot_end_time : strtotime( $slot_end_time );

		$rules = $this->get_availability_rules( $resource_id );

		foreach ( $rules as $rule ) {
			$type  = $rule['type'];
			$range = $rule['range'];

			if ( in_array( $type, array( 'days', 'custom', 'months', 'weeks' ) ) ) {
				continue;
			}

			if ( 'time:range' === $type ) {
				$year = date( 'Y', $slot_start_time );
				$month = date( 'n', $slot_start_time );
				$day = date( 'j', $slot_start_time );

				if ( ! isset( $range[ $year ][ $month ][ $day ] ) ) {
					continue;
				}

				$rule_val = $range[ $year ][ $month ][ $day ]['rule'];
				$from     = $range[ $year ][ $month ][ $day ]['from'];
				$to       = $range[ $year ][ $month ][ $day ]['to'];
			} else {
				if ( ! empty( $rules['day'] ) ) {
					if ( date( 'N', $slot_start_time ) != $range['day'] ) {
						continue;
					}
				}

				$rule_val = $range['rule'];
				$from     = $range['from'];
				$to       = $range['to'];
			}

			$start_time_hi      = $slot_start_time;
			$end_time_hi        = $slot_end_time;
			$rule_start_time_hi = strtotime( $from, $slot_start_time );
			$rule_end_time_hi   = strtotime( $to, $slot_start_time );

			// Reverse time rule - The end time is tomorrow e.g. 16:00 today - 12:00 tomorrow
			if ( $rule_end_time_hi <= $rule_start_time_hi ) {
				if ( $end_time_hi > $rule_start_time_hi ) {
					$bookable = $rule_val;
					break;
				}
				if ( $start_time_hi >= $rule_start_time_hi && $end_time_hi >= $rule_end_time_hi ) {
					$bookable = $rule_val;
					break;
				}
				// does this rule apply?
				// does slot start before rule start and end after rules start time {goes over start time}
				if ( $start_time_hi < $rule_start_time_hi && $end_time_hi > $rule_start_time_hi ) {
					$bookable = $rule_val;
					break;
				}
			} else {
				// Normal rule.
				if ( $start_time_hi >= $rule_start_time_hi && $end_time_hi <= $rule_end_time_hi ) {
					$bookable = $rule_val;
					break;
				}
			}
		}

		return $bookable;
	}

	/**
	 * Get an array of blocks within in a specified date range - might be days, might be blocks within days, depending on settings.
	 *
	 * @param       $start_date
	 * @param       $end_date
	 * @param array $intervals
	 * @param int   $resource_id
	 * @param array $booked
	 *
	 * @return array
	 */
	public function get_blocks_in_range( $start_date, $end_date, $intervals = array(), $resource_id = 0, $booked = array() ) {

		$duration_unit = $this->get_duration_unit();

		if ( empty( $intervals ) ) {
			$default_interval = 'hour' === $duration_unit ? $this->wc_booking_duration * 60 : $this->wc_booking_duration;
			$intervals        = array( $default_interval, $default_interval );
		}

		if ( 'day' === $duration_unit ) {
			$blocks_in_range = $this->get_blocks_in_range_for_day( $start_date, $end_date, $resource_id, $booked );
		} elseif ( 'month' === $duration_unit ) {
			$blocks_in_range = $this->get_blocks_in_range_for_month( $start_date, $end_date, $resource_id );
		} else {
			$blocks_in_range = $this->get_blocks_in_range_for_hour_or_minutes( $start_date, $end_date, $intervals, $resource_id, $booked );
		}

		return array_unique( $blocks_in_range );
	}

	/**
	 * Get blocks/day slots in range for day duration unit.
	 *
	 * @param $start_date
	 * @param $end_date
	 * @param $resource_id
	 * @param $booked
	 *
	 * @return array
	 */
	public function get_blocks_in_range_for_day( $start_date, $end_date, $resource_id, $booked ) {
		$blocks = array();
		$booking_resource = $resource_id ? $this->get_resource( $resource_id ) : null;
		$available_qty    = $this->has_resources() && $booking_resource && $booking_resource->has_qty() ? $booking_resource->get_qty() : $this->get_qty();

		// get booked days with a counter to specify how many bookings on that date
		$booked_days_with_count = array();
		foreach ( $booked as $booking ) {
			$booking_start = $booking[0];
			$booking_end   = $booking[1];
			$current_booking_day = $booking_start;

			// < because booking end depicts an end of a day and not a start for a new day.
			while ( $current_booking_day < $booking_end ) {
				$date = date( 'Y-m-d', $current_booking_day );

				if ( isset( $booked_days_with_count[ $date  ] ) ) {
					$booked_days_with_count[ $date ]++;
				} else {
					$booked_days_with_count[ $date ] = 1;
				}

				$current_booking_day = strtotime( '+1 day', $current_booking_day );
			}
		}

		// If exists always treat booking_period in minutes.
		$check_date = $start_date;
		while ( $check_date <= $end_date ) {
			if ( $this->check_availability_rules_against_date( $check_date, $resource_id ) ) {

				$date = date( 'Y-m-d', $check_date );
				if ( ! isset( $booked_days_with_count[ $date ] )
				     || $booked_days_with_count[ $date ] < $available_qty ) {
					$blocks[] = $check_date;
				}
			}

			// move to next day
			$check_date = strtotime( '+1 day', $check_date );
		}

		return $blocks;
	}

	/**
	 * For months, loop each month in the range to find blocks.
	 *
	 * @param $start_date
	 * @param $end_date
	 * @param $resource_id
	 *
	 * @return array
	 */
	public function get_blocks_in_range_for_month( $start_date, $end_date, $resource_id ) {

		$blocks = array();

		if ( 'month' !== $this->get_duration_unit() ) {
			return $blocks;
		}

		// Generate a range of blocks for months
		$from       = strtotime( date( 'Y-m-01', $start_date ) );
		$to         = strtotime( date( 'Y-m-t', $end_date ) );
		$month_diff = 0;
		$month_from = $from;

		while ( ( $month_from = strtotime( '+1 MONTH', $month_from ) ) <= $to ) {
			$month_diff ++;
		}

		for ( $i = 0; $i <= $month_diff; $i ++ ) {
			$year  = date( 'Y', ( $i ? strtotime( "+ {$i} month", $from ) : $from ) );
			$month = date( 'n', ( $i ? strtotime( "+ {$i} month", $from ) : $from ) );

			if ( ! $this->check_availability_rules_against_date( strtotime( "{$year}-{$month}-01" ), $resource_id ) ) {
				continue;
			}

			$blocks[] = strtotime( "+ {$i} month", $from );
		}
		return $blocks;
	}

	/**
	 * Get blocks in range for hour or minute duration unit.
	 * For minutes and hours find valid blocks within THIS DAY ($check_date)
	 *
	 * @param $start_date
	 * @param $end_date
	 * @param $intervals
	 * @param $resource_id
	 * @param $booked
	 *
	 * @return array
	 */
	public function get_blocks_in_range_for_hour_or_minutes( $start_date, $end_date, $intervals, $resource_id, $booked ) {

		$block_start_times_in_range     = array();
		$interval   = $intervals[0];
		$check_date = $start_date;

		// Setup.
		$first_block_time_minute  = $this->wc_booking_first_block_time ? ( date( 'H', strtotime( $this->wc_booking_first_block_time ) ) * 60 ) + date( 'i', strtotime( $this->wc_booking_first_block_time ) ) : 0;
		$default_bookable_minutes = $this->get_default_availability() ? range( $first_block_time_minute, ( 1440 + $interval ) ) : array();
		$rules                    = $this->get_availability_rules( $resource_id ); // Work out what minutes are actually bookable on this day
		// Get available slot start times.
		$minutes_not_available    = $this->get_unavailable_mintues( $booked );

		// Looping day by day look for available blocks
		while ( $check_date <= $end_date ) { // using `<=` instead of `<` because https://github.com/woothemes/woocommerce-bookings/issues/325

			$bookable_minutes_for_date = array_merge( $default_bookable_minutes, WC_Product_Booking_Rule_Manager::get_minutes_from_rules( $rules, $check_date ) );
			$bookable_start_and_end    = $this->get_bookable_minute_start_and_end( $bookable_minutes_for_date );

			if ( 'night' === $this->get_duration_unit() && ! $this->check_availability_rules_against_date( $check_date, $resource_id ) ) {
				$check_date = strtotime( '+1 day', $check_date );
				continue;
			}

			$blocks                     = $this->get_bookable_minute_blocks_for_date( $check_date, $start_date, $end_date, $bookable_start_and_end, $intervals, $resource_id, $minutes_not_available );
			$block_start_times_in_range = array_merge( $blocks, $block_start_times_in_range );

			$check_date = strtotime( '+1 day', $check_date );// Move to the next day
		}

		return $block_start_times_in_range;
	}

	/**
	 * @param array $bookable_minutes
	 *
	 * @return array
	 */
	public function get_bookable_minute_start_and_end( $bookable_minutes ) {

		// Break bookable minutes into sequences - bookings cannot have breaks
		$bookable_minute_blocks     = array();
		$bookable_minute_block_from = current( $bookable_minutes );

		foreach ( $bookable_minutes as $key => $minute ) {
			if ( isset( $bookable_minutes[ $key + 1 ] ) ) {
				if ( $bookable_minutes[ $key + 1 ] - 1 === $minute ) {
					continue;
				} else {
					// There was a break in the sequence
					$bookable_minute_blocks[]   = array( $bookable_minute_block_from, $minute );
					$bookable_minute_block_from = $bookable_minutes[ $key + 1 ];
				}
			} else {
				// We're at the end of the bookable minutes
				$bookable_minute_blocks[] = array( $bookable_minute_block_from, $minute );
			}
		}

		 //Find blocks that don't span any amount of time (same start + end)
		foreach ( $bookable_minute_blocks as $key => $bookable_minute_block ) {
			if ( $bookable_minute_block[0] === $bookable_minute_block[1] ) {
				$keys_to_remove[] = $key; // track which blocks need removed
			}
		}
		// Remove all of our blocks
		if ( ! empty( $keys_to_remove ) ) {
			foreach ( $keys_to_remove as $key ) {
				unset( $bookable_minute_blocks[ $key ] );
			}
		}

		return $bookable_minute_blocks;
	}

	/**
	 * Return an array of that is not available for booking.
	 *
	 * @since 1.9.13 introduced.
	 *
	 * @param array $booked. Pairs of booked slot start and end times.
	 * @return array $booked_minutes
	 */
	public function get_unavailable_mintues( $booked ) {
		$minutes_not_available = array();
		foreach ( $booked as $booked_block ) {
			for ( $i = $booked_block[0]; $i < $booked_block[1]; $i += 60 ) {
				array_push( $minutes_not_available, $i );
			}
		}

		$minutes_not_available = array_count_values( $minutes_not_available );
		$minutes_not_available = $this->apply_buffer( $minutes_not_available );

		return $minutes_not_available;
	}

	/**
	 * Get the Produt buffer period setting.
	 * @since 1.9.13 introduced.
	 * @return mixed $buffer_period
	 */
	public function get_buffer_period() {
		$buffer_period = get_post_meta( $this->id, '_wc_booking_buffer_period', true );
		// If exists always treat booking_period in minutes.
		if ( ! empty( $buffer_period ) && 'hour' === $this->get_duration_unit() ) {
			$buffer_period = $buffer_period * 60;
		}
		return $buffer_period;
	}

	/**
	 * Returns blocks/time slots from a given start and end minute blocks.
	 *
	 * This function take varied inputs but always retruns a block array of available slots.
	 * Sometimes it gets the minutes and see if all is available some times it needs to make up the
	 * minutes based on what is booked.
	 *
	 * It uses start and end date to figure things out.
	 *
	 * @since 1.9.13 introduced.
	 *
	 * @param $check_date
	 * @param $start_date
	 * @param $end_date
	 * @param $bookable_start_and_end
	 * @param $intervals
	 * @param $resource_id
	 * @param $minutes_not_available
	 *
	 * @return array
	 */
	public function get_bookable_minute_blocks_for_date( $check_date, $start_date, $end_date, $bookable_start_and_end, $intervals, $resource_id, $minutes_not_available ) {

		// blocks as in an array of slots. $slot_start_times
		$blocks = array();

		// boring interval stuff
		$interval              = $intervals[0];
		$base_interval         = $intervals[1];

		// get a time stamp to check from
		/// and get a time stamp to check to
		$product_min_date = $this->get_min_date();
		$product_max_date = $this->get_max_date();
		if ( 'hour' === $product_min_date['unit'] ) {
			// Adding 1 hour to round up to the next whole hour to return what is expected.
			$product_min_date['value'] = (int) $product_min_date['value'] + 1;
		}

		$min_check_from   = strtotime( "+{$product_min_date['value']} {$product_min_date['unit']}", current_time( 'timestamp' ) );
		$max_check_to     = strtotime( "+{$product_max_date['value']} {$product_max_date['unit']}", current_time( 'timestamp' ) );
		$min_date              = $this->get_min_timestamp_for_date( $start_date );
		$available_qty         = $this->get_available_quantity( $resource_id );

		$current_time_stamp = current_time( 'timestamp' );

		// Loop the blocks of bookable minutes and add a block if there is enough room to book
		foreach ( $bookable_start_and_end as $time_block ) {
			// the the slot start time calculation using end of the
			$time_block_start        = strtotime( "midnight +{$time_block[0]} minutes", $check_date );
			/* should rename ... block makes one think of slot*/
			$minutes_in_block        = $time_block[1] - $time_block[0];
			$base_intervals_in_block = floor( $minutes_in_block / $base_interval );
			$time_block_end_time = strtotime( "midnight +{$time_block[1]} minutes", $check_date );

			for ( $i = 0; $i < $base_intervals_in_block; $i ++ ) {
				$from_interval = $i * $base_interval;
				$to_interval   = $from_interval + $interval;
				$start_time    = strtotime( "+{$from_interval} minutes", $time_block_start );
				$end_time      = strtotime( "+{$to_interval} minutes", $time_block_start );

				// Break if start time is after the end date being calculated.
				if ( $start_time > $end_date ) {
					break 2;
				}

				// Must be in the future
				if ( $start_time < $min_date || $start_time <= $current_time_stamp ) {
					continue;
				}

				if ( isset( $minutes_not_available[ $start_time ] )
				     && $minutes_not_available[ $start_time ] >= $available_qty ) {
					continue;
				}

				// make sure minute & hour blocks are not past minimum & max booking settings.
				if ( $end_time < $min_check_from || $start_time > $max_check_to ) {
					continue;
				}

				if ( $end_time > $time_block_end_time ) {
					continue;
				}

				if ( ! $this->check_availability_rules_against_time( $start_time, $end_time, $resource_id ) ) {
					continue;
				}

				if ( $this->are_all_minutes_in_block_available( $start_time, $end_time, $available_qty )
				     && ! in_array( $start_time, $blocks ) ) {
					$blocks[] = $start_time;

				}
			}
		}

		return  $blocks;
	}

	/**
	 * Checks all minutes in block for availability. Comparing it with the minutes not available.
	 *
	 * @since 1.9.13
	 *
	 * @param $start_time
	 * @param $end_time
	 * @param $available_qty
	 *
	 * @return bool
	 */
	public function are_all_minutes_in_block_available( $start_time, $end_time, $available_qty ) {

		$loop_time = $start_time;

		while ( $loop_time < $end_time ) {
			if ( isset( $minutes_not_available[ $loop_time ] ) && $minutes_not_available[ $loop_time ] >= $available_qty ) {
				return false;
			}
			$loop_time = $loop_time + 60;
		}

		return true;
	}

	/**
	 * @since 1.9.13 introduced.
	 * @param $resource_id
	 *
	 * @return bool|int
	 */
	public function get_available_quantity( $resource_id = '' ) {
		$booking_resource      = $resource_id ? $this->get_resource( $resource_id ) : null;
		$available_qty         = $this->has_resources() && $booking_resource && $booking_resource->has_qty() ? $booking_resource->get_qty() : $this->get_qty();
		return $available_qty;
	}

	/**
	 * @since 1.9.13 introduced.
	 * @param $not_available_minutes
	 *
	 * @return mixed
	 */
	public function apply_buffer( $not_available_minutes ) {
		// loop through the unavailable minutes and apply
		// the buffer period after a booking
		// look for a minute after a booking to start applying buffer period
		// assuming that that time ranges are in order of earliest to latest
		$buffer_period_minute_count  = $this->get_buffer_period();
		$buffer_periods_in_timestamps = array();

		$one_minute = 60;
		foreach ( $not_available_minutes as $timestamp => $bookings_count ) {
			// if the next minute(after booking ) is not in the list not available minutes
			// then we should add a buffer from this point forward fro the duration of the buffer period in
			// minutes.

			if ( ! isset( $not_available_minutes[ $timestamp + $one_minute ] ) ) {
				$next_minute = $timestamp + $one_minute;
				for ( $j = 0;  $j < $buffer_period_minute_count; $j++ ) {
					$buffer_periods_in_timestamps[ $next_minute ] = 1;
					// increment the minute to the next with 60 seconds
					$next_minute = $next_minute + $one_minute;
				}
			}
			// apply buffer period backwards.
			// if there is no un-bookable blocks before the current
			// time in the loop and apply adjacent is enabled
			$backwards_buffer_periods = array();
			if ( 'yes' === $this->wc_booking_apply_adjacent_buffer && ! isset( $not_available_minutes[ $timestamp - $one_minute ] ) ) {

				$previous_minute = $timestamp - $one_minute;
				for ( $j = 0;  $j < $buffer_period_minute_count; $j++ ) {
					$backwards_buffer_periods[ $previous_minute ] = 1;
					// go backwards 60 seconds
					$previous_minute = $previous_minute - $one_minute;
				}
			}

			$buffer_periods_in_timestamps = $buffer_periods_in_timestamps + $backwards_buffer_periods;
		}

		return $not_available_minutes + $buffer_periods_in_timestamps;
	}

	/**
	 * Get the minutes that should be available based on the rules and the date to check.
	 *
	 * The minutes are returned in a range from the start incrementing minutes right up to the last available minute.
	 *
	 * @deprecated since 1.9.14
	 * @param array $rules
	 * @param int $check_date
	 *
	 * @return array $bookable_minutes
	 */
	public function get_minutes_from_rules( $rules, $check_date ) {
		return WC_Product_Booking_Rule_Manager::get_minutes_from_rules( $rules, $check_date );
	}

	/**
	 * Returns available blocks from a range of blocks by looking at existing bookings.
	 * @param  array   $blocks      The blocks we'll be checking availability for.
	 * @param  array   $intervals   Array containing 2 items; the interval of the block (maybe user set), and the base interval for the block/product.
	 * @param  integer $resource_id Resource we're getting blocks for. Falls backs to product as a whole if 0.
	 * @param  string  $from        The starting date for the set of blocks
	 * @return array The available blocks array
	 */
	public function get_available_blocks( $blocks, $intervals = array(), $resource_id = 0, $from = '' ) {
		if ( empty( $intervals ) ) {
			$default_interval = 'hour' === $this->get_duration_unit() ? $this->wc_booking_duration * 60 : $this->wc_booking_duration;
			$intervals        = array( $default_interval, $default_interval );
		}

		list( $interval, $base_interval ) = $intervals;
		$available_blocks   = array();
		if ( empty( $from ) ) {
			$start_date = current( $blocks );
		} else {
			$start_date = $from;
		}

		$end_date = end( $blocks );
		if ( ! empty( $blocks ) ) {
			/**
			 * Grab all existing bookings for the date range.
			 * Extend end_date to end of last block. Note: base_interval is in minutes.
			 * @var array
			 */
			$existing_bookings = $this->get_bookings_in_date_range( $start_date, $end_date + ( $base_interval * 60 ), $resource_id );

			// Resources booked array. Resource can be a "resource" but also just a booking if it has no resources
			$resources_booked = array( 0 => array() );

			// Loop all existing bookings
			foreach ( $existing_bookings as $booking ) {
				$booking_resource_id = $booking->get_resource_id();

				// prepare resource array for resource id
				$resources_booked[ $booking_resource_id ] = isset( $resources_booked[ $booking_resource_id ] ) ? $resources_booked[ $booking_resource_id ] : array();

				// if person multiplier is on we should disable stuff where nothing is avalible
				$repeat = max( 1, $this->has_person_qty_multiplier() && $booking->has_persons() ? $booking->get_persons_total() : 1 );

				for ( $i = 0; $i < $repeat; $i++ ) {
					array_push( $resources_booked[ $booking_resource_id ], array( $booking->start, $booking->end ) );
				}
			}

			// Generate arrays that contain information about what blocks to unset
			if ( $this->has_resources() && ! $resource_id ) {
				$resources       = $this->get_resources();
				$available_times = array();

				// Loop all resources
				foreach ( $resources as $resource ) {
					$times           = $this->get_blocks_in_range( $start_date, $end_date, array( $interval, $base_interval ), $resource->ID, isset( $resources_booked[ $resource->ID ] ) ? $resources_booked[ $resource->ID ] : array() );
					$available_times = array_merge( $available_times, $times );
				}
			} else {
				$available_times = $this->get_blocks_in_range( $start_date, $end_date, array( $interval, $base_interval ), $resource_id, isset( $resources_booked[ $resource_id ] ) ? $resources_booked[ $resource_id ] : $resources_booked[0] );
			}

			// Count booked times then loop the blocks
			$available_times = array_count_values( $available_times );

			// Loop through all blocks and unset if they are allready booked
			foreach ( $blocks as $block ) {
				if ( isset( $available_times[ $block ] ) ) {
					$available_blocks[] = $block;
				}
			}
		}

		// Even though we checked hours against other days/slots, make sure we only return blocks for this date..
		if ( in_array( $this->get_duration_unit(), array( 'minute', 'hour' ) ) && ! empty( $from ) ) {
			$time_blocks = array();
			foreach ( $available_blocks as $key => $block_date ) {
				if ( date( 'ymd', $block_date ) == date( 'ymd', $from ) ) {
					$time_blocks[] = $block_date;
				}
			}
			$available_blocks = $time_blocks;
		}

		/**
		 * Filter the available blocks for a product within a given range
		 *
		 * @since 1.9.8 introduced
		 *
		 * @param array $available_blocks
		 * @param WC_Product $bookings_product
		 * @param array $raw_range passed into this function.
		 * @param array $intervals
		 * @param integer $resource_id
		 */
		return apply_filters( 'wc_bookings_product_get_available_blocks', $available_blocks, $this, $blocks, $intervals, $resource_id );

	}

	/**
	 * Find available blocks and return HTML for the user to choose a block. Used in class-wc-bookings-ajax.php
	 * @param  array  $blocks
	 * @param  array  $intervals
	 * @param  integer $resource_id
	 * @param  string  $from The starting date for the set of blocks
	 * @return string
	 */
	public function get_available_blocks_html( $blocks, $intervals = array(), $resource_id = 0, $from = '' ) {
		if ( empty( $intervals ) ) {
			$default_interval = 'hour' === $this->get_duration_unit() ? $this->wc_booking_duration * 60 : $this->wc_booking_duration;
			$intervals        = array( $default_interval, $default_interval );
		}

		list( $interval, $base_interval ) = $intervals;

		$blocks            = $this->get_available_blocks( $blocks, $intervals, $resource_id, $from );
		$existing_bookings = $this->get_bookings_in_date_range( current( $blocks ), ( end( $blocks ) + ( $base_interval * 60 ) ), $resource_id );
		$booking_resource  = $resource_id ? $this->get_resource( $resource_id ) : null;
		$block_html        = '';

		foreach ( $blocks as $block ) {

			// Figure out how much qty have, either based on combined resource quantity,
			// single resource, or just product.
			if ( $this->has_resources() && ( is_null( $booking_resource ) || ! $booking_resource->has_qty() ) ) {

				$available_qty = 0;

				foreach ( $this->get_resources() as $resource ) {

					// Only include if it is available for this selection.
					if ( ! $this->check_availability_rules_against_date( $from, $resource->get_id() ) ) {
						continue;
					}

					$available_qty += $resource->get_qty();
				}
			} elseif ( $this->has_resources() && $booking_resource && $booking_resource->has_qty() ) {
				$available_qty = $booking_resource->get_qty();
			} else {
				$available_qty = $this->get_qty();
			}

			$qty_booked_in_block = 0;

			foreach ( $existing_bookings as $existing_booking ) {
				if ( $existing_booking->is_within_block( $block, strtotime( "+{$interval} minutes", $block ) ) ) {
					$qty_to_add = $this->has_person_qty_multiplier() ? max( 1, array_sum( $existing_booking->get_persons() ) ) : 1;
					if ( $this->has_resources() ) {
						if ( $existing_booking->get_resource_id() === absint( $resource_id ) ) {
							// Include the quantity to subtract if an existing booking matches the selected resource id
							$qty_booked_in_block += $qty_to_add;
						} elseif ( ( is_null( $booking_resource ) || ! $booking_resource->has_qty() ) && $existing_booking->get_resource() ) {
							// Include the quantity to subtract if the resource is auto selected (null/resource id empty)
							// but the existing booking includes a resource
							$qty_booked_in_block += $qty_to_add;
						}
					} else {
						$qty_booked_in_block += $qty_to_add;
					}
				}
			}

			$available_qty = $available_qty - $qty_booked_in_block;

			if ( $available_qty > 0 ) {
				if ( $qty_booked_in_block ) {
					$block_html .= '<li class="block" data-block="' . esc_attr( date( 'Hi', $block ) ) . '"><a href="#" data-value="' . date( 'G:i', $block ) . '">' . date_i18n( get_option( 'time_format' ), $block ) . ' <small class="booking-spaces-left">(' . sprintf( _n( '%d left', '%d left', $available_qty, 'woocommerce-bookings' ), absint( $available_qty ) ) . ')</small></a></li>';
				} else {
					$block_html .= '<li class="block" data-block="' . esc_attr( date( 'Hi', $block ) ) . '"><a href="#" data-value="' . date( 'G:i', $block ) . '">' . date_i18n( get_option( 'time_format' ), $block ) . '</a></li>';
				}
			}
		}

		return $block_html;
	}
}
