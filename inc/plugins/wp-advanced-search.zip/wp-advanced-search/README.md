# WP Advanced Search
#### A PHP framework for building advanced search forms in WordPress

[![Build Status](https://travis-ci.org/bootsz/wp-advanced-search.svg?branch=master)](https://travis-ci.org/bootsz/wp-advanced-search)
[![Code Climate](https://codeclimate.com/github/bootsz/wp-advanced-search/badges/gpa.svg)](https://codeclimate.com/github/bootsz/wp-advanced-search)

[View Documentation](http://wpadvancedsearch.com/docs/setup) | [Become a Contributor](http://wpadvancedsearch.com/beta/contributing)

**Technical Requirements:** PHP version 5.3 or higher, WordPress version 4.1 or higher
