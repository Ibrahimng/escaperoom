<?php

class Dokan_Test_Shipping extends WP_UnitTestCase {

    public function setup() {
        parent::setup();
    }

    public function tearDown() {
        parent::tearDown();
    }

    public function testSample() {
        $this->assertTrue( true );
    }
}