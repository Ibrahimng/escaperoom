Hi,

A new withdraw request has been made by %username%.

Request Amount: %amount%
Payment Method: %method%

Username: %username%
Profile: %profile_url%

You can approve or deny it by going here:
%withdraw_page%

---
Sent from %site_name%
%site_url%