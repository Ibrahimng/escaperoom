Hi,

Your refund request has been %status%.

Order ID: %order_id%
Refund Amount: %amount%
Refund Reason: %reason%

You can view the order details by going here:
%order_page%

---
Sent from %site_name%
%site_url%