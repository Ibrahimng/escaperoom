Hi,

New refund request for order # %order_id%.

You can process the request by going here:
%refund_page%

---
Sent from %site_name%
%site_url%