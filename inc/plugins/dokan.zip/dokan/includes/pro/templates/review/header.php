<?php
/**
 * Dokan Review Header Content Template
 *
 * @since 2.4
 *
 * @package dokan
 */
?>
<header class="dokan-dashboard-header">
    <h1 class="entry-title"><?php _e( 'Reviews', 'dokan' ); ?></h1>
</header><!-- .dokan-dashboard-header -->
