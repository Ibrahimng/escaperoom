<?php
/*
Plugin Name: Dokan - WooCommerce Booking Integration
Plugin URI: https://wedevs.com/products/plugins/dokan/woocommerce-booking-integration/
Description: This Plugin Integrates WooCommerce Booking with Dokan.
Version: 1.0
Author: weDevs
Author URI: https://wedevs.com
License: GPL2
*/

/**
 * Copyright (c) 2016 weDevs Team (email: info@wedevs.com). All rights reserved.
 *
 * Released under the GPL license
 * http://www.opensource.org/licenses/gpl-license.php
 *
 * This is an add-on for WordPress
 * http://wordpress.org/
 *
 * **********************************************************************
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * **********************************************************************
 */

// don't call the file directly
if ( !defined( 'ABSPATH' ) ) exit;


define( 'DOKAN_WC_BOOKING_PLUGIN_VERSION', '1.0' );
define( 'DOKAN_WC_BOOKING_DIR', dirname( __FILE__ ) );
define( 'DOKAN_WC_BOOKING_PLUGIN_ASSEST', plugins_url( 'assets', __FILE__ ) );

/**
 * Dokan_WC_Booking class
 *
 * @class Dokan_WC_Booking The class that holds the entire Dokan_WC_Booking plugin
 */
class Dokan_WC_Booking {
    private $depends_on = array();
    private $dependency_error = array();
    private $dependency_not_found = false;
    public $text_domain = 'dokan-wc-booking';
    /**
     * Constructor for the Dokan_WC_Booking class
     *
     * Sets up all the appropriate hooks and actions
     * within our plugin.
     *
     * @uses register_activation_hook()
     * @uses register_deactivation_hook()
     * @uses is_admin()
     * @uses add_action()
     */
    public function __construct() {
        register_activation_hook( __FILE__, array( $this, 'activate' ) );
        register_deactivation_hook( __FILE__, array( $this, 'deactivate' ) );

        $this->depends_on['dokan'] = array(
            'name'   => 'WeDevs_Dokan',
            'notice' => sprintf( __( '<b>Dokan WC Booking </b> requires %sDokan plugin%s to be installed & activated!', 'dokan-wc-booking' ), '<a target="_blank" href="https://wedevs.com/products/plugins/dokan/">', '</a>' ),
            );

        $this->depends_on['wc_bookings'] = array(
            'name'   => 'WC_Bookings',
            'notice' => sprintf( __( '<b>Dokan WC Booking </b> requires %sWooCommerce Bookings plugin%s to be installed & activated!', 'dokan-wc-booking' ), '<a target="_blank" href="http://www.woothemes.com/products/woocommerce-bookings/">', '</a>' ),
            );

        add_action( 'plugins_loaded', array( $this,'is_dependency_available') );



        // Localize our plugin
        add_action( 'init', array( $this, 'localization_setup' ) );

        // Loads frontend scripts and styles
        add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_scripts' ) );

        add_action( 'init', array( $this, 'init_hooks' ) );

        add_action( 'dokan_new_product_added', array( $this, 'save_booking_data' ) ,10 );
        add_action( 'dokan_product_updated', array( $this, 'save_booking_data' ) ,10 );

        //ajax
        add_action( 'wp_ajax_add_new_resource', array( $this, 'add_new_resource' ) );
        add_action( 'wp_ajax_nopriv_add_new_resource', array( $this, 'add_new_resource' ) );
        add_action( 'wp_ajax_delete_resource', array( $this, 'delete_resource' ) );
        add_action( 'wp_ajax_nopriv_delete_resource', array( $this, 'delete_resource' ) );
        add_action( 'wp_ajax_dokan_wc_booking_change_status', array( $this, 'change_booking_status' ) );
        add_action( 'wp_ajax_noprivdokan_wc_booking_change_status', array( $this, 'change_booking_status' ) );

        add_action( 'template_redirect', array( $this, 'update_resource_data' ) );

        //booking modification
        add_action( 'woocommerce_new_booking', array( $this, 'add_seller_id_meta' ) );
        add_action( 'shutdown', array( $this, 'add_seller_manage_cap' ) );
        add_action( 'wp_ajax_dokan-wc-booking-confirm', array( $this, 'mark_booking_confirmed' ) );

        // booking page filters
        add_filter( 'dokan_booking_menu', array($this, 'dokan_get_bookings_menu') );
        add_filter( 'dokan_booking_menu_title', array($this, 'dokan_get_bookings_menu_title') );

    }

    /**
     * check if dependencies installed or not and add error notice
     *
     * @since 1.0.0
     */
    function is_dependency_available(){

        $res = true;

        foreach ( $this->depends_on as $class ){
            if ( !class_exists( $class['name'] ) ){
                $this->dependency_error[] = $class['notice'];
                $res = false;
                $this->dependency_not_found = true;
            }
        }

        if ($res == false){
            add_action( 'admin_notices', array ( $this, 'dependency_notice' ) );
        }

        return $res;
    }

    /*
     * print error notice if dependency not active
     * @since 1.0.0
     */
    function dependency_notice(){

        $errors = '';
        $error = '';
        foreach ( $this->dependency_error as $error ) {
            $errors .= '<p>' . $error . '</p>';
        }
        $message = '<div class="error">' . $errors . '</div>';

        echo $message;

        deactivate_plugins( plugin_basename( __FILE__ ) );

    }

    /**
     * Initializes the Dokan_WC_Booking() class
     *
     * Checks for an existing Dokan_WC_Booking() instance
     * and if it doesn't find one, creates it.
     */
    public static function init() {
        static $instance = false;

        if ( ! $instance ) {
            $instance = new Dokan_WC_Booking();
        }

        return $instance;
    }

    /**
     * Placeholder for activation function
     *
     * Nothing being called here yet.
     */
    public function activate() {
        global $wp_roles;

    }

    /**
     * Placeholder for deactivation function
     *
     * Nothing being called here yet.
     */
    public function deactivate() {

    }

    /**
     * Initialize plugin for localization
     *
     * @uses load_plugin_textdomain()
     */
    public function localization_setup() {
        load_plugin_textdomain( 'dokan-wc-booking', false, dirname( plugin_basename( __FILE__ ) ) . '/languages/' );
    }

    /**
     * Enqueue admin scripts
     *
     * Allows plugin assets to be loaded.
     *
     * @uses wp_enqueue_script()
     * @uses wp_localize_script()
     * @uses wp_enqueue_style
     */
    public function enqueue_scripts() {

        global $wp;




        if ( !is_admin() && isset( $wp->query_vars['booking'] ) ) {
            global $post, $wp_scripts;

            /**
             * All styles goes here
             */
            wp_enqueue_style( 'dokan_wc_booking-styles', plugins_url( 'assets/css/style.css', __FILE__ ), false, date( 'Ymd' ) );
            /**
             * All scripts goes here
             */
            wp_enqueue_script( 'dokan_wc_booking-scripts', plugins_url( 'assets/js/script.js', __FILE__ ), array( 'jquery' ), false, true );

            $jquery_version = isset( $wp_scripts->registered['jquery-ui-core']->ver ) ? $wp_scripts->registered['jquery-ui-core']->ver : '1.9.2';

            $suffix = defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ? '' : '.min';
            wp_register_script( 'wc_bookings_writepanel_js', WC_BOOKINGS_PLUGIN_URL . '/assets/js/writepanel' . $suffix . '.js', array( 'jquery', 'jquery-ui-datepicker' ), WC_BOOKINGS_VERSION, true );
            wp_register_script( 'wc_bookings_settings_js', WC_BOOKINGS_PLUGIN_URL . '/assets/js/settings' . $suffix . '.js', array( 'jquery' ), WC_BOOKINGS_VERSION, true );
            wp_register_script( 'jquery-tiptip', WC()->plugin_url() . '/assets/js/jquery-tiptip/jquery.tipTip' . $suffix . '.js', array( 'jquery' ), WC_VERSION, true );
            $post_id = isset( $post->ID ) ? $post->ID : '';

            if ( dokan_is_seller_dashboard() ) {
                if ( isset( $_GET['product_id'] ) ) {
                    $post_id = $_GET['product_id'];
                } else {
                    $post_id = '';
                }
            }

            $params = array(
                'i18n_remove_person'     => esc_js( __( 'Are you sure you want to remove this person type?', 'dokan-wc-booking' ) ),
                'nonce_delete_person'    => wp_create_nonce( 'delete-bookable-person' ),
                'nonce_add_person'       => wp_create_nonce( 'add-bookable-person' ),

                'i18n_remove_resource'   => esc_js( __( 'Are you sure you want to remove this resource?', 'dokan-wc-booking' ) ),
                'nonce_delete_resource'  => wp_create_nonce( 'delete-bookable-resource' ),
                'nonce_add_resource'     => wp_create_nonce( 'add-bookable-resource' ),

                'i18n_minutes'           => esc_js( __( 'minutes', 'dokan-wc-booking' ) ),
                'i18n_days'              => esc_js( __( 'days', 'dokan-wc-booking' ) ),

                'i18n_new_resource_name' => esc_js( __( 'Enter a name for the new resource', 'dokan-wc-booking' ) ),
                'post'                   => $post_id,
                'plugin_url'             => WC()->plugin_url(),
                'ajax_url'               => admin_url( 'admin-ajax.php' ),
                'calendar_image'         => WC()->plugin_url() . '/assets/images/calendar.png',
                );

            wp_localize_script( 'wc_bookings_writepanel_js', 'wc_bookings_writepanel_js_params', $params );

            wp_enqueue_script( 'jquery-ui-datepicker' );
            wp_enqueue_script( 'wc_bookings_writepanel_js' );
            wp_enqueue_script( 'jquery-tiptip' );

            wp_enqueue_style( 'wc_bookings_admin_styles', WC_BOOKINGS_PLUGIN_URL . '/assets/css/admin.css', null, WC_BOOKINGS_VERSION );
            wp_enqueue_style( 'woocommerce_admin_styles', WC()->plugin_url() . '/assets/css/admin.css', null, WC_VERSION );
            wp_enqueue_style( 'jquery-ui-style', '//ajax.googleapis.com/ajax/libs/jqueryui/' . $jquery_version . '/themes/smoothness/jquery-ui.css' );

            add_filter( 'dokan_dashboard_nav_active', array( $this, 'set_booking_menu_as_active' ) );
        }


        /**
         * Example for setting up text strings from Javascript files for localization
         *
         * Uncomment line below and replace with proper localization variables.
         */
        // $translation_array = array( 'some_string' => __( 'Some string to translate', 'dokan_wc_booking' ), 'a_value' => '10' );
        // wp_localize_script( 'base-plugin-scripts', 'dokan_wc_booking', $translation_array ) );

    }

    function init_hooks() {

        if ( $this->dependency_not_found ) {
            return;
        }

        add_filter( 'dokan_get_dashboard_nav', array( $this, 'add_booking_page' ), 11, 1 );
        add_action( 'dokan_load_custom_template', array( $this, 'load_template_from_plugin' ) );
        add_filter( 'dokan_query_var_filter', array( $this, 'register_booking_queryvar' ) );
        add_filter( 'dokan_add_new_product_redirect', array( $this, 'set_redirect_url' ), 10, 2 );
        add_filter( 'dokan_product_listing_exclude_type', array( $this, 'exclude_booking_type_from_product_listing' ) );

        add_action( 'dokan_rewrite_rules_loaded', array( $this, 'add_rewrite_rules' ) );

        if ( !class_exists( 'WC_Product_Booking' ) && defined( 'WC_BOOKINGS_MAIN_FILE' ) ) {
            $wcb_path = preg_replace( '(woocommmerce-bookings.php)', '', WC_BOOKINGS_MAIN_FILE );
            include_once $wcb_path . 'includes/class-wc-product-booking.php';
        }

        if( !is_admin() ) {
            include_once DOKAN_WC_BOOKING_DIR . '/class-wc-booking-calendar.php';
        }
    }
    /**
     * Add menu on seller dashboard
     * @since 1.0
     * @param array $urls
     * @return array $urls
     */
    function add_booking_page( $urls ) {

        $urls['booking'] = array(
            'title' => __( 'Booking', $this->text_domain ),
            'icon'  => '<i class="fa fa-calendar"></i>',
            'url'   => dokan_get_navigation_url( 'booking' ),
            'pos'   => 180,
            );

        return $urls;
    }

    /**
     * Register page templates
     *
     * @since 1.0
     *
     * @param array $query_vars
     *
     * @return array $query_vars
     */
    function load_template_from_plugin( $query_vars ) {

        if ( isset( $query_vars['booking'] ) ) {
            $template = DOKAN_WC_BOOKING_DIR . '/templates/booking.php';
            include $template;
        }
    }

    /**
     * Register dokan query vars
     *
     * @since 1.0
     *
     * @param array $vars
     *
     * @return array new $vars
     */
    function register_booking_queryvar( $vars ) {
        $vars[] = 'booking';
        return $vars;
    }

    function add_rewrite_rules(){

    }


    /**
     * Save Booking meta data
     *
     * @since 1.0
     *
     * @global Array $wpdb
     *
     * @param int $post_id
     *
     * @return void
     */
    function save_booking_data( $post_id ) {
        global $wpdb;

        $product_type         = empty( $_POST['product_type'] ) ? 'simple' : sanitize_title( stripslashes( $_POST['product_type'] ) );
        $has_additional_costs = false;

        if ( 'booking' !== $product_type ) {
           return;
        }

		// Save meta
        $meta_to_save = array(
           '_wc_booking_base_cost'                  => 'float',
           '_wc_booking_cost'                       => 'float',
           '_wc_display_cost'                       => '',
           '_wc_booking_min_duration'               => 'int',
           '_wc_booking_max_duration'               => 'int',
           '_wc_booking_enable_range_picker'        => 'yesno',
           '_wc_booking_calendar_display_mode'      => '',

           '_wc_booking_qty'                        => 'int',

           '_wc_booking_has_persons'                => 'issetyesno',
           '_wc_booking_person_qty_multiplier'      => 'yesno',
           '_wc_booking_person_cost_multiplier'     => 'yesno',
           '_wc_booking_min_persons_group'          => 'int',
           '_wc_booking_max_persons_group'          => 'int',
           '_wc_booking_has_person_types'           => 'yesno',

           '_wc_booking_has_resources'              => 'issetyesno',
           '_wc_booking_resources_assignment'       => '',
           '_wc_booking_duration_type'              => '',
           '_wc_booking_duration'                   => 'int',
           '_wc_booking_duration_unit'              => '',
           '_wc_booking_user_can_cancel'            => '',
           '_wc_booking_cancel_limit'               => 'int',
           '_wc_booking_cancel_limit_unit'          => '',
           '_wc_booking_max_date'                   => 'max_date',
           '_wc_booking_max_date_unit'              => 'max_date_unit',
           '_wc_booking_min_date'                   => 'int',
           '_wc_booking_min_date_unit'              => '',
           '_wc_booking_buffer_period'              => 'int',
           '_wc_booking_first_block_time'           => '',
           '_wc_booking_requires_confirmation'      => 'yesno',
           '_wc_booking_default_date_availability'  => '',
           '_wc_booking_check_availability_against' => '',
           '_wc_booking_resouce_label'              => ''
           );

        foreach ( $meta_to_save as $meta_key => $sanitize ) {

           $value = ! empty( $_POST[ $meta_key ] ) ? $_POST[ $meta_key ] : '';
           switch ( $sanitize ) {
                case 'int' :
                $value = $value ? absint( $value ) : '';
                break;
                case 'float' :
                $value = $value ? floatval( $value ) : '';
                break;
                case 'yesno' :
                $value = $value == 'yes' ? 'yes' : 'no';
                break;
                case 'issetyesno' :
                $value = $value ? 'yes' : 'no';
                break;
                case 'max_date' :
                $value = absint( $value );
                if ( $value == 0 ) {
                  $value = 1;
                }
                break;
                default :
                $value = sanitize_text_field( $value );
            }
                update_post_meta( $post_id, $meta_key, $value );
        }

		// Availability
        $availability = array();
        $row_size     = isset( $_POST[ "wc_booking_availability_type" ] ) ? sizeof( $_POST[ "wc_booking_availability_type" ] ) : 0;
        for ( $i = 0; $i < $row_size; $i ++ ) {
           $availability[ $i ]['type']     = wc_clean( $_POST[ "wc_booking_availability_type" ][ $i ] );
           $availability[ $i ]['bookable'] = wc_clean( $_POST[ "wc_booking_availability_bookable" ][ $i ] );
           $availability[ $i ]['priority'] = intval( $_POST['wc_booking_availability_priority'][ $i ] );

           switch ( $availability[ $i ]['type'] ) {
                    case 'custom' :
                    $availability[ $i ]['from'] = wc_clean( $_POST[ "wc_booking_availability_from_date" ][ $i ] );
                    $availability[ $i ]['to']   = wc_clean( $_POST[ "wc_booking_availability_to_date" ][ $i ] );
                    break;
                    case 'months' :
                    $availability[ $i ]['from'] = wc_clean( $_POST[ "wc_booking_availability_from_month" ][ $i ] );
                    $availability[ $i ]['to']   = wc_clean( $_POST[ "wc_booking_availability_to_month" ][ $i ] );
                    break;
                    case 'weeks' :
                    $availability[ $i ]['from'] = wc_clean( $_POST[ "wc_booking_availability_from_week" ][ $i ] );
                    $availability[ $i ]['to']   = wc_clean( $_POST[ "wc_booking_availability_to_week" ][ $i ] );
                    break;
                    case 'days' :
                    $availability[ $i ]['from'] = wc_clean( $_POST[ "wc_booking_availability_from_day_of_week" ][ $i ] );
                    $availability[ $i ]['to']   = wc_clean( $_POST[ "wc_booking_availability_to_day_of_week" ][ $i ] );
                    break;
                    case 'time' :
                    case 'time:1' :
                    case 'time:2' :
                    case 'time:3' :
                    case 'time:4' :
                    case 'time:5' :
                    case 'time:6' :
                    case 'time:7' :
                    $availability[ $i ]['from'] = wc_booking_sanitize_time( $_POST[ "wc_booking_availability_from_time" ][ $i ] );
                    $availability[ $i ]['to']   = wc_booking_sanitize_time( $_POST[ "wc_booking_availability_to_time" ][ $i ] );
                    break;
                    case 'time:range' :
                    $availability[ $i ]['from'] = wc_booking_sanitize_time( $_POST[ "wc_booking_availability_from_time" ][ $i ] );
                    $availability[ $i ]['to']   = wc_booking_sanitize_time( $_POST[ "wc_booking_availability_to_time" ][ $i ] );

                    $availability[ $i ]['from_date'] = wc_clean( $_POST[ 'wc_booking_availability_from_date' ][ $i ] );
                    $availability[ $i ]['to_date']   = wc_clean( $_POST[ 'wc_booking_availability_to_date' ][ $i ] );
                    break;
            }
        }
        update_post_meta( $post_id, '_wc_booking_availability', $availability );

        		// Pricing
        $pricing = array();
        $row_size     = isset( $_POST[ "wc_booking_pricing_type" ] ) ? sizeof( $_POST[ "wc_booking_pricing_type" ] ) : 0;
        for ( $i = 0; $i < $row_size; $i ++ ) {
           $pricing[ $i ]['type']          = wc_clean( $_POST[ "wc_booking_pricing_type" ][ $i ] );
           $pricing[ $i ]['cost']          = wc_clean( $_POST[ "wc_booking_pricing_cost" ][ $i ] );
           $pricing[ $i ]['modifier']      = wc_clean( $_POST[ "wc_booking_pricing_cost_modifier" ][ $i ] );
           $pricing[ $i ]['base_cost']     = wc_clean( $_POST[ "wc_booking_pricing_base_cost" ][ $i ] );
           $pricing[ $i ]['base_modifier'] = wc_clean( $_POST[ "wc_booking_pricing_base_cost_modifier" ][ $i ] );

               switch ( $pricing[ $i ]['type'] ) {
                case 'custom' :
                $pricing[ $i ]['from'] = wc_clean( $_POST[ "wc_booking_pricing_from_date" ][ $i ] );
                $pricing[ $i ]['to']   = wc_clean( $_POST[ "wc_booking_pricing_to_date" ][ $i ] );
                break;
                case 'months' :
                $pricing[ $i ]['from'] = wc_clean( $_POST[ "wc_booking_pricing_from_month" ][ $i ] );
                $pricing[ $i ]['to']   = wc_clean( $_POST[ "wc_booking_pricing_to_month" ][ $i ] );
                break;
                case 'weeks' :
                $pricing[ $i ]['from'] = wc_clean( $_POST[ "wc_booking_pricing_from_week" ][ $i ] );
                $pricing[ $i ]['to']   = wc_clean( $_POST[ "wc_booking_pricing_to_week" ][ $i ] );
                break;
                case 'days' :
                $pricing[ $i ]['from'] = wc_clean( $_POST[ "wc_booking_pricing_from_day_of_week" ][ $i ] );
                $pricing[ $i ]['to']   = wc_clean( $_POST[ "wc_booking_pricing_to_day_of_week" ][ $i ] );
                break;
                case 'time' :
                case 'time:1' :
                case 'time:2' :
                case 'time:3' :
                case 'time:4' :
                case 'time:5' :
                case 'time:6' :
                case 'time:7' :
                $pricing[ $i ]['from'] = wc_booking_sanitize_time( $_POST[ "wc_booking_pricing_from_time" ][ $i ] );
                $pricing[ $i ]['to']   = wc_booking_sanitize_time( $_POST[ "wc_booking_pricing_to_time" ][ $i ] );
                break;
                case 'time:range' :
                $pricing[ $i ]['from'] = wc_booking_sanitize_time( $_POST[ "wc_booking_pricing_from_time" ][ $i ] );
                $pricing[ $i ]['to']   = wc_booking_sanitize_time( $_POST[ "wc_booking_pricing_to_time" ][ $i ] );

                $pricing[ $i ]['from_date'] = wc_clean( $_POST[ 'wc_booking_pricing_from_date' ][ $i ] );
                $pricing[ $i ]['to_date']   = wc_clean( $_POST[ 'wc_booking_pricing_to_date' ][ $i ] );
                break;
                default :
                $pricing[ $i ]['from'] = wc_clean( $_POST[ "wc_booking_pricing_from" ][ $i ] );
                $pricing[ $i ]['to']   = wc_clean( $_POST[ "wc_booking_pricing_to" ][ $i ] );
                break;
            }

            if ( $pricing[ $i ]['cost'] > 0 ) {
                $has_additional_costs = true;
            }
        }

        update_post_meta( $post_id, '_wc_booking_pricing', $pricing );

		// Resources
        if ( isset( $_POST['resource_id'] ) && isset( $_POST['_wc_booking_has_resources'] ) ) {
           $resource_ids         = $_POST['resource_id'];
           $resource_menu_order  = $_POST['resource_menu_order'];
           $resource_base_cost   = $_POST['resource_cost'];
           $resource_block_cost  = $_POST['resource_block_cost'];
           $max_loop             = max( array_keys( $_POST['resource_id'] ) );
           $resource_base_costs  = array();
           $resource_block_costs = array();

           for ( $i = 0; $i <= $max_loop; $i ++ ) {
                if ( ! isset( $resource_ids[ $i ] ) ) {
                continue;
                }

                $resource_id = absint( $resource_ids[ $i ] );

                $wpdb->update(
                    "{$wpdb->prefix}wc_booking_relationships",
                    array(
                    'sort_order'  => $resource_menu_order[ $i ]
                    ),
                    array(
                    'product_id'  => $post_id,
                    'resource_id' => $resource_id
                    )
                );

                $resource_base_costs[ $resource_id ]  = wc_clean( $resource_base_cost[ $i ] );
                $resource_block_costs[ $resource_id ] = wc_clean( $resource_block_cost[ $i ] );

                if ( ( $resource_base_cost[ $i ] + $resource_block_cost[ $i ] ) > 0 ) {
                $has_additional_costs = true;
                }
            }

        update_post_meta( $post_id, '_resource_base_costs', $resource_base_costs );
        update_post_meta( $post_id, '_resource_block_costs', $resource_block_costs );
        }

		// Person Types
        if ( isset( $_POST['person_id'] ) && isset( $_POST['_wc_booking_has_persons'] ) ) {
           $person_ids         = $_POST['person_id'];
           $person_menu_order  = $_POST['person_menu_order'];
           $person_name        = $_POST['person_name'];
           $person_cost        = $_POST['person_cost'];
           $person_block_cost  = $_POST['person_block_cost'];
           $person_description = $_POST['person_description'];
           $person_min         = $_POST['person_min'];
           $person_max         = $_POST['person_max'];

           $max_loop = max( array_keys( $_POST['person_id'] ) );

           for ( $i = 0; $i <= $max_loop; $i ++ ) {
                if ( ! isset( $person_ids[ $i ] ) ) {
                    continue;
                }

                $person_id = absint( $person_ids[ $i ] );

                 if ( empty( $person_name[ $i ] ) ) {
                     $person_name[ $i ] = sprintf( __( 'Person Type #%d', 'dokan-wc-booking' ), ( $i + 1 ) );
                 }

                $wpdb->update(
                     $wpdb->posts,
                     array(
                      'post_title'   => stripslashes( $person_name[ $i ] ),
                      'post_excerpt' => stripslashes( $person_description[ $i ] ),
                      'menu_order'   => $person_menu_order[ $i ] ),
                     array(
                      'ID' => $person_id
                      ),
                     array(
                      '%s',
                      '%s',
                      '%d'
                      ),
                     array( '%d' )
                     );

                 update_post_meta( $person_id, 'cost', wc_clean( $person_cost[ $i ] ) );
                 update_post_meta( $person_id, 'block_cost', wc_clean( $person_block_cost[ $i ] ) );
                 update_post_meta( $person_id, 'min', wc_clean( $person_min[ $i ] ) );
                 update_post_meta( $person_id, 'max', wc_clean( $person_max[ $i ] ) );

                 if ( $person_cost[ $i ] > 0 || $person_block_cost[ $i ] > 0 ) {
                     $has_additional_costs = true;
                 }
            }
        }

        update_post_meta( $post_id, '_has_additional_costs', ( $has_additional_costs ? 'yes' : 'no' ) );
        update_post_meta( $post_id, '_regular_price', '' );
        update_post_meta( $post_id, '_sale_price', '' );
        update_post_meta( $post_id, '_manage_stock', 'no' );

		// Set price so filters work - using get_base_cost()
        $bookable_product = wc_get_product( $post_id , array( 'product_type' => 'booking' ));
        update_post_meta( $post_id, '_price', $bookable_product->get_base_cost() );
}

    /**
     * Filter Redirect url after new booking product added
     *
     * @since 1.0
     *
     * @param string $url
     *
     * @param int $product_id
     *
     * @return $url
     */
    function set_redirect_url( $url, $product_id ) {

        $product_type = isset( $_POST['product_type'] ) ? $_POST['product_type'] : '';
        $tab = isset( $_GET['tab'] ) ? $_GET['tab'] : '';

        if ( 'booking' == $product_type ) {
            $url = add_query_arg( array( 'product_id' => $product_id ),dokan_get_navigation_url('booking').'edit/');
            return $url;
        }

        if ( 'booking' == $tab ) {
            $url = add_query_arg( array(),dokan_get_navigation_url('booking'));
            return $url;
        }

        return $url;
    }

    /**
     * Add new resource via ajax
     *
     * @since 1.0
     *
     * @return void
     *
     */
    function add_new_resource() {

        $add_resource_name = wc_clean( $_POST['add_resource_name'] );

        if ( empty( $add_resource_name ) ) {
            wp_send_json_error();
        }

        $resource    = array(
            'post_title'   => $add_resource_name,
            'post_content' => '',
            'post_status'  => 'publish',
            'post_author'  => get_current_user_id(),
            'post_type'    => 'bookable_resource'
            );
        $resource_id = wp_insert_post( $resource );
        $edit_url    = dokan_get_navigation_url( 'booking' ) . 'resources/edit/?id=' . $resource_id;
        ob_start();
        ?>
        <tr>
            <td><a href="<?php echo $edit_url ?>"><?php echo $add_resource_name ?></a></td>
            <td>'N/A'</td>
            <td>
             <button class="dokan-btn dokan-btn-theme dokan-btn-sm btn-remove" data-id="<?php echo $resource_id ?>"><?php _e( 'Remove', 'dokan-wc-booking' );  ?></button>
         </td>
     </tr>

     <?php
     $output = ob_get_clean();
     wp_send_json_success( $output );
 }

   /**
    * Update Resource Data via ajax
    *
    * @since 1.0
    *
    * @return void
    */
   function update_resource_data() {
    if ( !isset( $_POST['dokan_booking_resource_update'] ) ) {
        return;
    }

    $post_id = $_POST[ 'resource_id' ];

    $post = get_post( $post_id );
    $post->post_title = $_POST[ 'post_title' ];

    wp_update_post( $post );

        // Qty field
    update_post_meta( $post_id, 'qty', wc_clean( $_POST['_wc_booking_qty'] ) );
        // Availability
    $availability = array();
    $row_size     = isset( $_POST["wc_booking_availability_type"] ) ? sizeof( $_POST["wc_booking_availability_type"] ) : 0;
    for ( $i = 0; $i < $row_size; $i ++ ) {
        $availability[$i]['type']     = wc_clean( $_POST["wc_booking_availability_type"][$i] );
        $availability[$i]['bookable'] = wc_clean( $_POST["wc_booking_availability_bookable"][$i] );
        $availability[$i]['priority'] = intval( $_POST['wc_booking_availability_priority'][$i] );

        switch ( $availability[$i]['type'] ) {
            case 'custom' :
            $availability[$i]['from'] = wc_clean( $_POST["wc_booking_availability_from_date"][$i] );
            $availability[$i]['to']   = wc_clean( $_POST["wc_booking_availability_to_date"][$i] );
            break;
            case 'months' :
            $availability[$i]['from'] = wc_clean( $_POST["wc_booking_availability_from_month"][$i] );
            $availability[$i]['to']   = wc_clean( $_POST["wc_booking_availability_to_month"][$i] );
            break;
            case 'weeks' :
            $availability[$i]['from'] = wc_clean( $_POST["wc_booking_availability_from_week"][$i] );
            $availability[$i]['to']   = wc_clean( $_POST["wc_booking_availability_to_week"][$i] );
            break;
            case 'days' :
            $availability[$i]['from'] = wc_clean( $_POST["wc_booking_availability_from_day_of_week"][$i] );
            $availability[$i]['to']   = wc_clean( $_POST["wc_booking_availability_to_day_of_week"][$i] );
            break;
            case 'time' :
            case 'time:1' :
            case 'time:2' :
            case 'time:3' :
            case 'time:4' :
            case 'time:5' :
            case 'time:6' :
            case 'time:7' :
            $availability[$i]['from'] = wc_booking_sanitize_time( $_POST["wc_booking_availability_from_time"][$i] );
            $availability[$i]['to']   = wc_booking_sanitize_time( $_POST["wc_booking_availability_to_time"][$i] );
            break;
            case 'time:range' :
            $availability[$i]['from'] = wc_booking_sanitize_time( $_POST["wc_booking_availability_from_time"][$i] );
            $availability[$i]['to']   = wc_booking_sanitize_time( $_POST["wc_booking_availability_to_time"][$i] );

            $availability[$i]['from_date'] = wc_clean( $_POST['wc_booking_availability_from_date'][$i] );
            $availability[$i]['to_date']   = wc_clean( $_POST['wc_booking_availability_to_date'][$i] );
            break;
        }
    }
    update_post_meta( $post_id, '_wc_booking_availability', $availability );

    $redirect_url = dokan_get_navigation_url( 'booking' ).'resources/edit/?id='.$post_id;
    wp_redirect( add_query_arg( array( 'message' => 'success' ), $redirect_url ) );
}

    /**
     * Delete Booking resource
     *
     * @since 1.0
     *
     * @return JSON Success | Error
     */
    function delete_resource(){
        $post_id = wc_clean( $_POST['resource_id'] );

        if( wp_delete_post( $post_id ) ){
            wp_send_json_success();
        }else{
            wp_send_json_error();
        }
    }

    /**
     * Highlight Booking menu as active on Dokan Dashboard
     *
     * @since 1.0
     *
     * @param string $active_menu
     *
     * @return string
     */
    function set_booking_menu_as_active( $active_menu ){
        return 'booking';
    }

    /**
     * Add Seller meta to newly created Booking
     *
     * @since 1.0
     *
     * @param int $booking_id Newly created booking id
     *
     * @return void
     */
    function add_seller_id_meta( $booking_id ) {
        $product_id = get_post_meta( $booking_id, '_booking_product_id', true );
        $seller_id = get_post_field( 'post_author', $product_id );
        update_post_meta( $booking_id, '_booking_seller_id', $seller_id );
    }

    /**
     * Exclude Booking type products from dokan product listing
     *
     * @since 1.0
     *
     * @param array $product_types
     *
     * @return array $product_types
     */
    function exclude_booking_type_from_product_listing( $product_types ) {
        $product_types[] = 'booking';
        return $product_types;
    }

    /**
     * Add Booking Manage capability to seller
     *
     * @since 1.0
     *
     * @global type $wp_roles
     *
     * @return void
     */
    function add_seller_manage_cap() {
        global $wp_roles;

        if ( is_object( $wp_roles ) ) {
            $wp_roles->add_cap( 'seller', 'manage_bookings' );
        }
    }

    /**
     * Confirm bookings from seller dashboard with additional security checks
     *
     * @since 1.0
     *
     * @return void
     *
     */
    function mark_booking_confirmed() {

        if ( !current_user_can( 'manage_bookings' ) ) {
            wp_die( __( 'You do not have sufficient permissions to access this page.', 'woocommerce-bookings' ) );
        }
        if ( !check_admin_referer( 'wc-booking-confirm' ) ) {
            wp_die( __( 'You have taken too long. Please go back and retry.', 'woocommerce-bookings' ) );
        }
        $booking_id = isset( $_GET['booking_id'] ) && (int) $_GET['booking_id'] ? (int) $_GET['booking_id'] : '';
        if ( !$booking_id ) {
            die;
        }

        // Additional check to see if Seller id is same as current user
        $seller = get_post_meta( $booking_id, '_booking_seller_id', true );

        if ( $seller != get_current_user_id() ) {
            wp_die( __( 'You do not have sufficient permissions to access this page.', 'woocommerce-bookings' ) );
        }

        $booking = get_wc_booking( $booking_id );

        if ( $booking->get_status() !== 'confirmed' ) {
            $booking->update_status( 'confirmed' );
        }

        wp_safe_redirect( wp_get_referer() );
    }


    public static function get_booking_status_counts_by( $seller_id ) {

        global $wpdb;

        $cache_key = 'dokan-wc-booking-status-count-'.$seller_id;
        $counts = wp_cache_get( $cache_key );

        if( 1 ) {

            $statuses = array_unique( array_merge( get_wc_booking_statuses(), get_wc_booking_statuses( 'user' ), get_wc_booking_statuses( 'cancel') ) );

            $statuses = array_fill_keys( array_keys( array_flip($statuses) ), 0);

            $counts = $statuses + array('total' => 0);
            $meta_key = '_booking_seller_id';

            $sql = "Select post_status
            From $wpdb->posts as p
            LEFT JOIN $wpdb->postmeta as pm ON p.ID = pm.post_id
            WHERE
            pm.meta_key = %s AND
            pm.meta_value = %d AND
            p.post_status != 'trash' ";

            $results = $wpdb->get_results( $wpdb->prepare( $sql, $meta_key, $seller_id ) );



            if ( $results ) {
                $total = 0;

                foreach ( $results as $status ) {
                    if ( isset( $counts[$status->post_status] ) ) {
                        $counts[$status->post_status] += 1;
                        $counts['total'] += 1;
                    }
                }
            }

            $counts = (object) $counts;

            wp_cache_set( $cache_key, $counts, 'dokan-wc-booking' );
        }

        return $counts;
    }

    function change_booking_status() {

        check_ajax_referer( 'dokan_wc_booking_change_status' );

        $booking_id = intval( $_POST['booking_id'] );
        $booking    = get_wc_booking( $booking_id );

        $status = wc_clean( $_POST['booking_order_status'] );

        if ( $booking->update_status( $status ) ) {
            echo sprintf( '<label class="dokan-label dokan-booking-label-%s">%s</label>', $status, get_post_status_object( $status )->label );
        } else {
            echo _e( "Error Occured" , 'dokan-wc-booking');
        }

        exit();
    }

     /**
     * Returns the Booking menu Items
     *
     * @since 1.1
     * @return array
     */
     function dokan_get_bookings_menu($bookings) {
        $bookings = array(
            "" => array(
                'title' => __( 'All Booking Product', 'dokan' ),
                'tabs' => true
                ),
            "new-product" => array(
                'title' => __( 'Add Booking Product', 'dokan' ),
                'tabs' => false
                ),
            "my-bookings" => array(
                'title' => __( 'Manage Bookings', 'dokan' ),
                'tabs' => true
                ),
            "calendar" => array(
                'title' => __( 'Calendar', 'dokan' ),
                'tabs' => true
                ),
            "resources" => array(
                'title' => __( 'Manage Resources', 'dokan' ),
                'tabs' => true
                ),
            "edit" => array(
                'title' => __( 'Edit Booking Product', 'dokan' ),
                'tabs' => false
                ),
            "resources/edit" => array(
                'title' => __( 'Edit Resource', 'dokan' ),
                'tabs' => false
                )
            );

        return $bookings;
    }

    /**
     * Returns the Booking menu Items Title
     *
     * @since 1.1
     * @return array
     */
    function dokan_get_bookings_menu_title($current_page) {

        $menus=apply_filters( 'dokan_booking_menu', '' );

        foreach ( $menus as $key => $value) {

            if( $current_page == $key ){
                $title = $value['title'];
            }
        }
        return $title;
    }


} // Dokan_WC_Booking

$dokan_wc_booking = Dokan_WC_Booking::init();
