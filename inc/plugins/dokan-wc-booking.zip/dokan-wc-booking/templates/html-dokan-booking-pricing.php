<?php
$booking_cost         = get_post_meta( $post_id, '_wc_booking_cost', true );
$booking_base_cost    = get_post_meta( $post_id, '_wc_booking_base_cost', true );
$booking_display_cost = get_post_meta( $post_id, '_wc_display_cost', true )
?>

<div class="cost_fields dokan-edit-row dokan-clearfix">
    <div class="dokan-side-left">
        <h2>Costs</h2>
        <p>Set Costs options</p>
    </div>
    <div id="bookings_pricing" class="dokan-side-right">
        <div class="dokan-form-group">
            <label for="_wc_booking_cost" class="form-label"><?php _e( 'Base cost', 'dokan-wc-booking' ); ?>
                <span class="dokan-tooltips-help tips" title="" data-original-title="<?php _e( 'One-off cost for the booking as a whole.', 'dokan-wc-booking' ); ?>">
                    <i class="fa fa-question-circle"></i>
                </span>
            </label>
            <?php dokan_post_input_box( $post_id, '_wc_booking_cost', array( 'min' => '', 'step' => '0.1', 'value' => $booking_cost ), 'number' ); ?>
        </div>
        <?php do_action( 'woocommerce_bookings_after_booking_base_cost', $post_id ); ?>
        
        <div class="dokan-form-group">
            <label for="_wc_booking_base_cost" class="form-label"><?php _e( 'Block cost', 'dokan-wc-booking' ); ?>
                <span class="dokan-tooltips-help tips" title="" data-original-title="<?php _e( 'This is the cost per block booked. All other costs (for resources and persons) are added to this.', 'dokan-wc-booking' ); ?>">
                    <i class="fa fa-question-circle"></i>
                </span>
            </label>
            <?php dokan_post_input_box( $post_id, '_wc_booking_base_cost', array( 'min' => '', 'step' => '0.1', 'value' => $booking_base_cost ), 'number' ); ?>
        </div>
        <?php do_action( 'woocommerce_bookings_after_booking_block_cost', $post_id ); ?>
        
        <div class="dokan-form-group">
            <label for="_wc_display_cost" class="form-label"><?php _e( 'Display cost', 'dokan-wc-booking' ); ?>
                <span class="dokan-tooltips-help tips" title="" data-original-title="<?php _e( 'The cost is displayed to the user on the frontend. Leave blank to have it calculated for you. If a booking has varying costs, this will be prefixed with the word "from:".', 'dokan-wc-booking' ); ?>">
                    <i class="fa fa-question-circle"></i>
                </span>
            </label>
            <?php dokan_post_input_box( $post_id, '_wc_display_cost', array( 'min' => '', 'step' => '0.1', 'value' => $booking_display_cost ), 'number' ); ?>
        </div>
        <?php do_action( 'woocommerce_bookings_after_display_cost', $post_id ); ?>
        
        <div class="table_grid dokan-booking-range-table">
            <table class="widefat dokan-booking-range-table">
                <thead>
                    <tr>
                        <th class="sort" width="1%">&nbsp;</th>
                        <th><?php _e( 'Range type', 'dokan-wc-booking' ); ?></th>
                        <th><?php _e( 'Range', 'dokan-wc-booking' ); ?></th>
                        <th></th>
                        <th></th>
                        <th><?php _e( 'Base cost', 'dokan-wc-booking' ); ?>&nbsp;
                            <span class="dokan-tooltips-help tips" title="" data-original-title="<?php _e( 'Enter a cost for this rule. Applied to the booking as a whole.', 'dokan-wc-booking' ); ?>">
                                <i class="fa fa-question-circle"></i>
                            </span>
                        <th><?php _e( 'Block cost', 'dokan-wc-booking' ); ?>&nbsp;
                            <span class="dokan-tooltips-help tips" title="" data-original-title="<?php _e( 'Enter a cost for this rule. Applied to each booking block.', 'dokan-wc-booking' ); ?>">
                                <i class="fa fa-question-circle"></i>
                            </span>
                            <!--<a class="tips" data-tip="<?php // _e( 'Enter a cost for this rule. Applied to each booking block.', 'dokan-wc-booking' );   ?>">[?]</a></th>-->
                        <th class="remove" width="1%">&nbsp;</th>
                    </tr>
                </thead>
                <tfoot>
                    <tr>
                        <th colspan="8">
                            <a href="#" class="button button-primary add_row dokan-btn dokan-btn-theme" data-row="<?php
                            ob_start();
                            include( 'html-booking-pricing-fields.php' );
                            $html   = ob_get_clean();
                            echo esc_attr( $html );
                            ?>"><?php _e( 'Add Range', 'dokan-wc-booking' ); ?></a>
                            <span class="description"><?php _e( 'All matching rules will be applied to the booking.', 'dokan-wc-booking' ); ?></span>
                        </th>
                    </tr>
                </tfoot>
                <tbody id="pricing_rows">
                    <?php
                    $values = get_post_meta( $post_id, '_wc_booking_pricing', true );
                    if ( !empty( $values ) && is_array( $values ) ) {
                        foreach ( $values as $pricing ) {
                            include( 'html-booking-pricing-fields.php' );

                            /**
                             * Fired just after pricing fields are rendered.
                             * 
                             * @since 1.7.4
                             * 
                             * @param array		$pricing {
                             * 	The pricing details for bookings
                             * 
                             * 	@type string $type	The booking range type
                             * 	@type string $from	The start value for the range
                             * 	@type string $to	The end value for the range
                             * 	@type string $modifier	The arithmetic modifier for block cost
                             * 	@type string $cost	The booking block cost
                             * 	@type string $base_modifier The arithmetic modifier for base cost
                             * 	@type string $base_cost	The base cost
                             * }
                             */
                            do_action( 'woocommerce_bookings_pricing_fields', $pricing );
                        }
                    }
                    ?>
                </tbody>
            </table>
        </div>

    </div>
</div>