<?php

$booking_id = $_GET[ 'booking_id' ];

$the_booking = get_wc_booking( $booking_id );

if ( !dokan_is_seller_has_order( get_current_user_id(), $the_booking->order_id ) ) {
    echo '<div class="dokan-alert dokan-alert-danger">' . __( 'This is not yours, I swear!', 'dokan' ) . '</div>';
    return;
}

$order_url = add_query_arg( 'order_id', $the_booking->order_id, dokan_get_navigation_url( 'orders' ) );

$product = $the_booking->get_product();

$statuses  = array_unique( array_merge( get_wc_booking_statuses( 'user' ), get_wc_booking_statuses( 'cancel') ) );
?>

<header class="dokan-dashboard-header dokan-clearfix">
    <h1 class="entry-title">
        <?php _e( 'Booking Details', 'dokan-wc-booking'); ?>
    </h1>
    <h4>
        <?php echo sprintf( __('Booking Number: #%d. Order Number:<a href="%s"> #%d </a>' ), $booking_id, $order_url, $the_booking->order_id  ); ?>
    </h4>
</header><!-- .entry-header -->

<div>
    <article>
        <div class="dokan-clearfix">
            <div class="dokan-w8" style="margin-right:3%;">

                <div class="dokan-clearfix">
                    <div class="" style="width:100%">
                        <div class="dokan-panel dokan-panel-default">
                            <div class="dokan-panel-heading"><strong><?php _e( 'Details' , 'dokan' ) ?></strong></div>
                            <div class="dokan-panel-body">
                                <div class="dokan-booking-general-details">
                                    <ul class="list-unstyled order-status">

                                        <li>
                                            <span class="dokan-booking-label"><?php _e( 'Booking Status:', 'dokan-wc-booking' ); ?></span>
                                            <label class="dokan-label dokan-booking-label-<?php echo $the_booking->status; ?>"><?php echo get_post_status_object( $the_booking->status )->label ?></label>
                                            <a href="#" class="dokan-edit-status"><small><?php _e( '&nbsp; Edit', 'dokan-wc-booking' ); ?></small></a>
                                        </li>

                                        <li class="dokan-hide">
                                            <form id="dokan-order-status-form" action="" method="post">

                                                <select id="booking_order_status" name="booking_order_status" class="form-control">
                                                    <?php
                                                    foreach ( $statuses as $status ) {
                                                        echo '<option value="' . esc_attr( $status ) . '" ' . selected( $status, $the_booking->status, false ) . '>' . get_post_status_object( $status )->label . '</option>';
                                                    }
                                                    ?>
                                                </select>

                                                <input type="hidden" name="booking_id" value="<?php echo $the_booking->id; ?>">
                                                <input type="hidden" name="action" value="dokan_wc_booking_change_status">
                                                <input type="hidden" name="_wpnonce" value="<?php echo wp_create_nonce( 'dokan_wc_booking_change_status' ); ?>">
                                                <input type="submit" class="dokan-btn dokan-btn-success dokan-btn-sm" name="dokan_change_status" value="<?php _e( 'Update', 'dokan-wc-booking' ); ?>">

                                                <a href="#" class="dokan-btn dokan-btn-default dokan-btn-sm dokan-cancel-status"><?php _e( 'Cancel', 'dokan' ) ?></a>
                                            </form>
                                        </li>

                                        <li>
                                            <span class="dokan-booking-label"><?php _e( 'Order Date :', 'dokan-wc-booking' ); ?></span>
                                            <?php echo $the_booking->booking_date; ?>
                                        </li>

                                        <li>
                                            <span class="dokan-booking-label"><?php _e( 'Booked Product : ', 'dokan-wc-booking' ); ?></span>
                                            <?php 
                                            $product_url = add_query_arg( 'product_id',$the_booking->get_product_id(), dokan_get_navigation_url( 'booking/edit' ) );  
                                            ?>
                                            <?php  echo "<a href='".$product_url."'>".$the_booking->get_product()->post->post_title."</a>";?>
                                        </li>

                                        <?php if ( $the_booking->has_resources() ) : 
                                        $resource = $the_booking->get_resource();
                                        $resource_label = get_post_meta( $the_booking->get_product_id(), '_wc_booking_resouce_label', true );
                                        ?>
                                        <li><span class="dokan-booking-label"><?php _e( 'Resource(s) :', 'dokan-wc-booking') ?></span></li>
                                        <li>
                                            <span class="dokan-booking-label" style="margin-left:20px"><?php echo $resource_label.' :'?></span>
                                            <?php echo  $resource->post_title  ?>
                                        </li>
                                    <?php endif; ?>

                                    <?php if ( $the_booking->has_persons() ) : 
                                    
                                    $saved_persons = get_post_meta( $the_booking->id, '_booking_persons', true );

                                    if ( ! empty ( $product ) ) {
                                        $person_types = $product->get_person_types();
                                        if ( ! empty( $person_types ) && is_array( $person_types ) ) {
                                            echo '<li><span class="dokan-booking-label">' . __( 'Person(s) :', 'woocommerce-bookings' ) . '</span></li>';

                                            foreach ( $person_types as $person_type ) {
                                                $person_count = ( isset( $saved_persons[ $person_type->ID ] ) ? $saved_persons[ $person_type->ID ] : 0 );
                                                echo '<li><span class="dokan-booking-label" style="margin-left:20px">'.$person_type->post_title. ' : </span>'.$person_count. '</li>';
                                            }
                                        } else if ( empty( $person_types ) && ! empty( $saved_persons ) && is_array( $saved_persons ) ) {
                                            echo '<li><span class="dokan-booking-label">' . __( 'Person(s) :', 'woocommerce-bookings' ) . '</span></li>';

                                            foreach ( $saved_persons as $person_id => $person_count ) {
                                                echo '<li><span class="dokan-booking-label" style="margin-left:20px">'.get_the_title( $person_id ). ' : '.$person_count. '</span></li>';
                                            }
                                        }
                                    }
                                    endif; 
                                    ?>
                                    <li>
                                        <span class="dokan-booking-label"><?php _e( 'Booking Start Date :', 'dokan-wc-booking' ); ?></span>
                                        <?php echo $the_booking->get_start_date() ?>
                                    </li>

                                    <li>
                                        <span class="dokan-booking-label"><?php _e( 'Booking End Date :', 'dokan-wc-booking' ); ?></span>
                                        <?php echo $the_booking->get_end_date() ?>
                                    </li>

                                    <li>
                                        <span class="dokan-booking-label"><?php _e( 'Duration :', 'dokan-wc-booking' ); ?></span>
                                        <?php echo $product->get_duration().' '.$product->get_duration_unit(); ?>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>


                <div class="dokan-left">

                </div>

                <div class="clear"></div>


            </div>
        </div>

        <div class="dokan-w4">
            <div class="row dokan-clearfix">
                <div class="" style="width:100%">
                    <div class="dokan-panel dokan-panel-default">
                        <div class="dokan-panel-heading"><strong>Customer Details</strong></div>
                        <div class="dokan-panel-body general-details">
                            <?php 
                            $customer_id = get_post_meta( $the_booking->id, '_booking_customer_id', true );
                            $order_id    = $the_booking->order_id;
                            $has_data    = false;

                            echo '<table class="booking-customer-details">';

                            if ( $customer_id && ( $user = get_user_by( 'id', $customer_id ) ) ) {
                             echo '<tr>';
                             echo '<th>' . __( 'Name:', 'woocommerce-bookings' ) . '</th>';
                             echo '<td>';
                             if ( $user->last_name && $user->first_name ) {
                               echo $user->first_name . ' ' . $user->last_name;
                           } else {
                               echo '-';
                           }
                           echo '</td>';
                           echo '</tr>';
                           echo '<tr>';
                           echo '<th>' . __( 'User Email:', 'woocommerce-bookings' ) . '</th>';
                           echo '<td>';
                           echo '<a href="mailto:' . esc_attr( $user->user_email ) . '">' . esc_html( $user->user_email ) . '</a>';
                           echo '</td>';
                           echo '</tr>';
                           $has_data = true;
                       }

                       if ( $order_id && ( $order = wc_get_order( $order_id ) ) ) {
                         echo '<tr>';
                         echo '<th>' . __( 'Address:', 'woocommerce-bookings' ) . '</th>';
                         echo '<td>';
                         if ( $order->get_formatted_billing_address() ) {
                           echo wp_kses( $order->get_formatted_billing_address(), array( 'br' => array() ) );
                       } else {
                           echo __( 'No billing address set.', 'dokan-wc-booking' );
                       }
                       echo '</td>';
                       echo '</tr>';
                       echo '<tr>';
                       echo '<th>' . __( 'Email:', 'woocommerce-bookings' ) . '</th>';
                       echo '<td>';
                       echo '<a href="mailto:' . esc_attr( $order->billing_email ) . '">' . esc_html( $order->billing_email ) . '</a>';
                       echo '</td>';
                       echo '</tr>';
                       echo '<tr>';
                       echo '<th>' . __( 'Phone:', 'woocommerce-bookings' ) . '</th>';
                       echo '<td>';
                       echo esc_html( $order->billing_phone );
                       echo '</td>';
                       echo '</tr>';
                       echo '<tr class="view">';
                       echo '<th>&nbsp;</th>';
                       echo '<td>';
                       echo '<a class="dokan-btn dokan-btn-sm dokan-btn-theme" target="_blank" href="' . $order_url . '">' . __( 'View Order', 'woocommerce-bookings' ) . '</a>';
                       echo '</td>';
                       echo '</tr>';

                       $has_data = true;
                   }

                   if ( ! $has_data ) {
                     echo '<tr>';
                     echo '<td colspan="2">' . __( 'N/A', 'woocommerce-bookings' ) . '</td>';
                     echo '</tr>';
                 }

                 echo '</table>';
                 ?>

             </div>
         </div>
     </div>

 </div> <!-- .row -->
</div> <!-- .col-md-4 -->
</div>
</article>
</div>
