<?php

$current_page = get_query_var( 'booking' );
?>

<div class="dokan-dashboard-wrap">

<?php

    /**
     *  dokan_dashboard_content_before hook
     *  dokan_dashboard_support_content_before
     *
     *  @hooked get_dashboard_side_navigation
     *
     *  @since 2.4
     */
    do_action( 'dokan_dashboard_content_before' );
    do_action( 'dokan_dashboard_support_content_before' );
    ?>

    <div class="dokan-dashboard-content dokan-booking-wrapper dokan-product-edit">
        <?php 

        $booking_url = dokan_get_navigation_url('booking');
        $menus = apply_filters( 'dokan_booking_menu', '' );
        $title = apply_filters( 'dokan_booking_menu_title', $current_page );

        ?>


        <ul class="dokan_tabs">
            <?php
            foreach ( $menus as $key => $value) {
                $class = ( $current_page == $key ) ? ' class="active"' : '';
                if( $value[ 'tabs' ] !== false)
                printf( '<li%s><a href="%s">%s</a></li>', $class, $booking_url.$key, $value[ 'title' ] );
            }
            ?>
        </ul>
        <?php
        switch ( $current_page ) {
            case 'my-bookings':
            include_once DOKAN_WC_BOOKING_DIR.'/templates/my-bookings/all-bookings.php';
            break;
            case 'booking-details':
            include_once DOKAN_WC_BOOKING_DIR.'/templates/my-bookings/booking-details.php';
            break;
            case 'new-product':
            include_once DOKAN_WC_BOOKING_DIR.'/templates/new-product.php';
            break;
            case 'edit':
            include_once DOKAN_WC_BOOKING_DIR.'/templates/new-product.php';
            break;
            case 'calendar' :
            include_once DOKAN_WC_BOOKING_DIR.'/templates/calendar.php';
            break;
            case 'resources' :
            include_once DOKAN_WC_BOOKING_DIR.'/templates/resources.php';
            break;
            case 'resources/edit' :
            include_once DOKAN_WC_BOOKING_DIR.'/templates/edit-resource.php';
            break;
            case '':
            include_once DOKAN_WC_BOOKING_DIR.'/templates/product-list.php';
            break;
            default:
            break;
        }
        ?>
    </div><!-- .dokan-dashboard-content -->

    <?php

    /**
     *  dokan_dashboard_content_after hook
     *  dokan_dashboard_support_content_after hook
     *
     *  @since 2.4
     */
    do_action( 'dokan_dashboard_content_after' );
    do_action( 'dokan_dashboard_support_content_after' );
    ?>

</div><!-- .dokan-dashboard-wrap -->