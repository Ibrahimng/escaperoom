;(function($) {

	console.log(dps);

	var pricingPane = $('#woocommerce-product-data');

		if ( pricingPane.length ) {
			pricingPane.find('.pricing').addClass('show_if_product_pack').end()
				.find('.inventory_tab').addClass('hide_if_product_pack').end()
				.find('.shipping_tab').addClass('hide_if_product_pack').end()
				.find('.linked_product_tab').addClass('hide_if_product_pack').end()
				.find('.attributes_tab').addClass('hide_if_product_pack').end()
				.find('._no_of_product_field').hide().end()
				.find('._pack_validity_field').hide()
		}


	// $('.options_group.subscription_pricing').hide();

	$('body').on('woocommerce-product-type-change',function(event, select_val){

		$('._no_of_product_field').hide();
		$('._pack_validity_field').hide();
		$('._enable_recurring_payment_field').hide();
		$('.subscription_pricing').hide();
	    $('._sale_price_field').show();

		if ( select_val == 'product_pack' ) {
			$('._no_of_product_field').show();
			$('._pack_validity_field').show();
			$('._enable_recurring_payment_field').show();
			$('._sale_price_field').hide();
		}

		if( $( '#_enable_recurring_payment' ).is( ":checked" ) ) {
			$('.subscription_pricing').show();
			$('._pack_validity_field').hide();
		}
	});


	$('.woocommerce_options_panel').on('change', '#_enable_recurring_payment', function() {

		$('.subscription_pricing').hide();
		$('._pack_validity_field').show();

		if ( $(this).is(':checked') ) {
			$('.subscription_pricing').slideDown();
			$('._pack_validity_field').hide();
		}
	});

	// $('.woocommerce_options_panel #_enable_recurring_payment').change();

})(jQuery);